#include "5_10.h"
#include <iostream> // input and output stream
#include <math.h>
#include <assert.h>

void swap_row(double **matrix, int i, int j, int size){
      for (int k=0; k< size; k++) {
          double temp = matrix[i][k];
          matrix[i][k] = matrix[j][k];
          matrix[j][k] = temp;
      }
  }
  void swap_row_vector(double *vector, int i, int j){
        double temp = vector[i];
        vector[i] = vector[j];
        vector[j] = temp;
    }

void sort_rows(double **matrix, double *vector, int col, int row, int size) {
  int next = row;
  while (next < size) {
    if (matrix[next][col] < matrix[row][col]){
      swap_row(matrix, next, row, size);
      swap_row_vector(vector, next, row);
    }
    row +=1;
    if (row == size){
      next += 1;
      row = next;
    }
  }
}

void solve_upper_triangle(double **A, double *b, double*u, int size){
  u[size-1] = b[size-1]/A[size-1][size-1];
  for (int k = size-2; k >= 0; k--) {
    double sum = 0;
    for (size_t i = 0; i < size; i++) {
      sum += A[k][i]*u[i];
    }
    u[k] = (b[k]-sum)/A[k][k];
  }
}

void gaussian_elimination(double **A, double *b, double *u, int n){
  int size = n;
  double m;
  for (int row = 0; row < size; row++) {
    sort_rows(A, b, row, row, size);
    for (int i = row+1; i < size; i++) {
    m = A[i][row]/A[row][row];
    b[i] -= m*b[row];
    for (int j = 0; j < size; j++) {
      A[i][j] -= m*A[row][j];
      }
    }
  }

  solve_upper_triangle(A, b, u, n);

}
