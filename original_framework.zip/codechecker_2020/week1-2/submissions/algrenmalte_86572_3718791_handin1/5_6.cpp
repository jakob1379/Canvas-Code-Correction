#include "5_4.h"
#include <iostream> // input and output stream
#include <math.h>
#include <assert.h>

void Multiply(double **res, double **A, double **B, int ARows, int ACols, int BRows, int BCols){
  assert (BRows == ARows);
  assert (BCols == ACols);
  for (int i = 0; i < ARows; i++) {
    for (int j = 0; j < ACols; j++) {
      for (int iter = 0; iter < ACols; iter++) {
          res[i][j] += A[i][iter]*B[iter][j];
      }
    }
  }
  };
void Multiply(double *res, double *A, double **B, int ACols, int BRows, int BCols){
  assert (ACols == BRows);
  for (int col = 0; col < ACols; col++) {
    for (int row = 0; row < BRows; row++) {
      res[col] += A[row]*B[col][row];
    }
  }
  };
void Multiply(double *res, double **A, double *B, int ARows, int ACols, int BRows){
  assert (ACols == BRows);
  for (int col = 0; col < ACols; col++) {
    for (int row = 0; row < BRows; row++) {
      res[col] += A[col][row]*B[row];
    }
  }
};
void Multiply(double **res, double scalar, double **B, int BRows, int BCols){
  for (int row = 0; row < BRows; row++) {
    for (int col = 0; col < BCols; col++) {
      res[row][col] += B[row][col]*scalar;
    }
  }
};
void Multiply(double **res, double **B, double scalar, int BRows, int BCols){
  for (int row = 0; row < BRows; row++) {
    for (int col = 0; col < BCols; col++) {
      res[row][col] += B[row][col]*scalar;
    }
  }
};
