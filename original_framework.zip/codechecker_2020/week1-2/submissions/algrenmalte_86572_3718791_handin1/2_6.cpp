#include "2_6.h"
#include <iostream> // input and output stream
#include <math.h>       /* exp */

double NR (double x){
  return exp(x)+pow(x, 3)-5;}

double NR_diff (double x){
  return exp(x)+3*pow(x, 2);}

double NR_cal (double x_last){
  return x_last-(NR(x_last)/NR_diff(x_last));}

double newton_Raphson(double initialGuess, double epsilon){
  double x_new =  NR_cal(initialGuess);
  while (fabs(x_new-initialGuess) > epsilon){
    std::cout << "Difference between new and old: " << x_new -initialGuess << '\n';
    initialGuess = x_new;
    std::cout << "Value: " << initialGuess << '\n';
    x_new =  NR_cal(initialGuess);
  }
  std::cout << "Less than " << epsilon <<" difference in abs(x_i x_(i-1))" << '\n'<< '\n';
  return x_new;
}
