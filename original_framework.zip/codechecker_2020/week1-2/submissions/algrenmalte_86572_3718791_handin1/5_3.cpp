#include "5_3.h"
#include <iostream> // input and output stream
#include <math.h>

void swap_pointer(double *a, double *b){
  double store;
  store = *a;
  *a = *b;
  *b = store;
  };

void swap_ref(double &a, double &b){
  double store;
  store = a;
  a = b;
  b = store;

  return;
  };
