#include "5_4.h"
#include <iostream> // input and output stream
#include <math.h>

double calc_std(double a[], int length){
  double mean = 0.0;
  for (int i = 0; i < length; i++) {
    mean += a[i];
  }
  mean = mean/length;

  double std = 0;
  for (int i = 0; i < length; i++) {
    std += pow(a[i]-mean, 2);
  }
  std = sqrt(std/(length-1));
  return std;
};
double calc_mean(double a[], int length){
  double mean = 0.0;
  for (int i = 0; i < length; i++) {
    mean += a[i];
  }
  mean = mean/length;

  return mean;
};
