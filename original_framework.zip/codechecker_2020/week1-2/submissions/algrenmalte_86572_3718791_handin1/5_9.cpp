#include "5_9.h"
#include <iostream> // input and output stream
#include <math.h>
#include <assert.h>

void swap_row_3(double **matrix, int i, int j){
      for (int k=0; k< 3; k++) {
          double temp = matrix[i][k];
          matrix[i][k] = matrix[j][k];
          matrix[j][k] = temp;
      }
  }
  void swap_row_vector_3(double *vector, int i, int j){
        double temp = vector[i];
        vector[i] = vector[j];
        vector[j] = temp;
    }

void sort_rows_3(double **matrix, double *vector, int col, int row, int size) {
  int next = row;
  while (next < size) {
    if (matrix[next][col] < matrix[row][col]){
      swap_row_3(matrix, next, row);
      swap_row_vector_3(vector, next, row);
    }
    row +=1;
    if (row == size){
      next += 1;
      row = next;
    }
  }
}

void solve_upper_triangle_3(double **A, double *b, double*u, int size){
  u[size-1] = b[size-1]/A[size-1][size-1];
  for (int k = size-2; k >= 0; k--) {
    double sum = 0;
    for (size_t i = 0; i < size; i++) {
      sum += A[k][i]*u[i];
    }
    u[k] = (b[k]-sum)/A[k][k];
  }
}

void solve3by3(double **A, double *b, double *u){
  int size = (sizeof(A)+1)/3;
  double m;
  for (int row = 0; row < size; row++) {
    sort_rows_3(A, b, row, row, size);
    for (int i = row+1; i < size; i++) {
    m = A[i][row]/A[row][row];
    b[i] -= m*b[row];
    for (int j = 0; j < size; j++) {
      A[i][j] -= m*A[row][j];
      }
    }
  }

  solve_upper_triangle_3(A, b, u, 3);

};
