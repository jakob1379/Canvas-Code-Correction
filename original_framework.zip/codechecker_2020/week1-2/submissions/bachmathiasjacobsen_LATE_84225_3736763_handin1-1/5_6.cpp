#include <iostream>
#include "5_6.h"
#include <cmath>
#include <cassert>
#include <fstream>

void Multiply(double **res , double **A, double **B, int ARows, int ACols , int BRows, int BCols){
    if (ACols==BRows){
int index_1;
int index_2;
int index_3;
for (index_1 = 0; index_1 < ARows; index_1++){
        for(index_2 = 0; index_2 < BCols; index_2++){
            for (index_3 = 0; index_3 < ACols; index_3++){
            res[index_1][index_2] += A[index_1][index_3] * B[index_3][index_2];
            }
            }
        }
    }}

void Multiply(double *res , double *A, double **B, int ACols , int BRows, int BCols){
    if (ACols==BRows){
int index_1;
int index_2;
		res[0] = 0;
		for(index_1=0; index_1<BCols; index_1++) {
			for(index_2=0; index_2<ACols; index_2++) {
				res[index_1] += B[index_2][index_1]*A[index_2];
			}
		}
    }}

void Multiply(double *res , double **A, double *B, int ARows, int ACols , int BRows){
    if (ACols==BRows){
    int index_1;
int index_2;

	for(index_1=0; index_1<ARows; index_1++) {
		res[index_1] = 0;
		for(index_2=0; index_2<ACols; index_2++) {
			res[index_1] += A[index_1][index_2]*B[index_2];
		}
	}
    }}


void Multiply(double **res , double scalar , double **B, int BRows, int BCols){
	int index_1;
	int index_2;
	for(index_1=0; index_1<BRows; index_1++) {
		for(index_2=0; index_2<BCols; index_2++) {
			res[index_1][index_2] = (B[index_1][index_2])*scalar;
		}
	}
}



void Multiply(double **res, double **B, double scalar, int BRows, int BCols){
int index_1;
int index_2;
for(index_1=0; index_1<BRows; index_1++) {
		for(index_2=0; index_2<BCols; index_2++) {
			res[index_1][index_2] = (B[index_1][index_2])*scalar;
		}
	}
}
