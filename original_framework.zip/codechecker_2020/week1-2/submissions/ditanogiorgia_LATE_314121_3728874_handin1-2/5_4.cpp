//
//  5_4.cpp
//
//  Exercise 5.4
//

// *** DESCRIPTION *** //
// Functions to compute mean and standard deviation of an array of double
// precision floating point numbers.


#include "5_4.h"
#include <cmath>


// *** FUNCTIONS DEFINITION *** //


// Mean

double calc_mean(double a[], int length)
{
    double mean = 0.0;
    
    for (int i = 0; i < length; i++)
    {
        mean += a[i];
    }
    
    mean = mean / length;
    return mean;
}


// Standard deviation

double calc_std(double a[], int length)
{
    double sd = 0.0, m = calc_mean(a, length);
    
    if (length != 1)
    {
        for (int i = 0; i < length; i++)
        {
            double sqres = pow(a[i] - m, 2);
            sd += sqres;
        }
        sd = sqrt( sd / (length - 1) );
    }

    else
        sd = 0.0;
    
    return sd;
}




