//
//  2_6.cpp
//
//  Exercise 2.6
//

//*** DESCRIPTION *** //
// Function implementing the Newton-Raphson method for the function
// f(x) = exp(x) + pow(x, 3) - 5.


#include "2_6.h"
#include <cmath>


// *** FUNCTION DEFINITION *** //

double newton_Raphson(double initialGuess, double epsilon)
{
    double f, f_prime, x_prev, x_next = initialGuess;
    do
    {
        x_prev = x_next;
        f = exp(x_prev) + pow(x_prev, 3) - 5;
        f_prime = exp(x_prev) + 3 * pow(x_prev, 2);
        x_next = x_prev - f / f_prime; // Updating x value
    }
    while ( !(fabs(x_next - x_prev) < epsilon) );
         // Condition: size of the x variation is larger than epsilon
    
    return x_next;

}
