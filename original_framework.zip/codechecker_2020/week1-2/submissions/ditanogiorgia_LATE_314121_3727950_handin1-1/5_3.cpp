//
//  5_3.cpp
//
//  Exercise 5.3
//

// *** DESCRIPTION *** //
// Function swapping values of two double precision floating point numbers,
// so that these changes are visible in the code that has called the function:
// (1) using pointers; (2) using references.


#include "5_3.h"

// *** FUNCTIONS DEFINITION *** //

// (1) Using pointers

void swap_pointer(double *a, double *b)
{
    double temp = *a;
    *a = *b;
    *b = temp;
}


// (2) Using references

void swap_ref(double &a, double &b)
{
    double temp = a;
    a = b;
    b = temp;
}


