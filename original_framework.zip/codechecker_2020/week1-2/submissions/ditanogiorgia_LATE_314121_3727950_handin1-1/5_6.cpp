//
//  5_6.cpp
//
//  Exercise 5.6
//

// *** DESCRIPTION *** //

// Overloaded function usable to multiply: (1) two matrix of given sizes,
// (2) a vector and a matrix of given sizes, (3) a matrix and a vector of
// given sizes, (4) a scalar and a matrix of given size, (5) a matrix of
// given size and a scalar.


#include "5_6.h"
#include <cassert>
#include <iostream>



// (1) Matrix * Matrix

void Multiply(double **res, double **A, double **B, int ARows, int ACols, int BRows, int BCols)
{
    // Checking multipliability (with possibility of re-entering
    // arguments, if in wrong sequence)
    if (ACols != BRows)
    {
        if (BCols == ARows)
            std::cout << "The matrices to multiply should be passed to the function in reversed sequence. \n";
        else
            std::cout << "The matrices are not conformable. \n";
    }
     
    else
    {
        for (int i = 0; i < ARows; i++)
        {
            for (int j = 0; j < BCols; j++)
            {
                res[i][j] = 0; // Ensuring res matrix is empty
                
                for (int k = 0; k < ACols; k++)
                    res[i][j] += A[i][k] * B[k][j];
            }
        }
    }
}





// (2) Vector * Matrix

void Multiply(double *res, double *A, double **B, int ACols, int BRows, int BCols)
{
    assert(ACols == BRows); // Checking multipliability
    
    for (int j = 0; j < BCols; j++)
    {
        res[j] = 0; // Ensuring res vector is empty
        
        for (int k = 0; k < ACols; k++)
            res[j] += A[k] * B[k][j];
    }
}





// (3) Matrix * Vector

void Multiply(double *res, double **A, double *B, int ARows, int ACols, int BRows)
{
    assert(ACols == BRows); // Checking multipliability
    
    for (int i = 0; i < ARows; i++)
    {
        res[i] = 0; // Ensuring res vector is empty
        
        for (int k = 0; k < BRows; k++)
            res[i] += A[i][k] * B[k];
    }
}





// (4) Scalar * Matrix

void Multiply(double **res, double scalar, double **B, int BRows, int BCols)
{
    for (int i = 0; i < BRows; i++)
    {
         for (int j = 0; j < BCols; j++)
             res[i][j] = scalar * B[i][j];
    }
}





// (5) Matrix * Scalar

void Multiply(double **res, double **B, double scalar, int BRows, int BCols)
{
    for (int i = 0; i < BRows; i++)
    {
         for (int j = 0; j < BCols; j++)
             res[i][j] = scalar * B[i][j];
    }
}


