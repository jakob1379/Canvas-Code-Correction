//
//  3_3.cpp
//
//  Exercise 3.3
//

// *** DESCRIPTION *** //
// Function implementing the implicit (or backward) Euler method to solve the
// initial value ordinary differential equation.


#include "3_3.h"
#include <cassert>
#include <fstream>


// *** FUNCTION DEFINITION *** //
// The function takes in input the desired number of grid points (n)
// and result in a .dat file containing the x and y values computed.

void implicit_Euler(int n)
{
    assert(n > 1);
    double x = 0, y = 1, h = (1.0 / (double)(n)); // h = step size
    
    std::ofstream xy_file("xy.dat");
    assert(xy_file.is_open());
    xy_file << x << ", " << y << "\n";
    
    for (int i = 1; i <= n; i++)
    {
        x = i * h;
        y /= (1 + h);
        xy_file << x << ", " << y << "\n";
    }
    
    xy_file.close();
}



