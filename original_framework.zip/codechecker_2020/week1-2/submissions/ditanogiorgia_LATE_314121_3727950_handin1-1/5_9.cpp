//
//  5_9.cpp
//
//  Exercise 5.9 - Function definition
//

// *** DESCRIPTION *** //
// Module for solving the 3 × 3 linear system Au = b
// where A is nonsingular.


#include "5_9.h"


// *** Internal functions - DECLARATION *** //


void invertMatrix(double **M, double **M_inv);

void Multiply(double **C, double *d, double *res);





// *** Function to call the module - DEFINITION *** //

void solve3by3(double **A, double *b, double *u)
{
    // Declaring and initializing inverse matrix to pass to the internal
    // function (to store the inverse)
    double** A_inv;
    A_inv = new double* [3];
    for (int i = 0; i < 3; i++)
        A_inv[i] = new double [3];
    
    
    // Computing inverse matrix
    invertMatrix(A, A_inv);
    
    // Multplying inverse matrix A_inv and vector b
    Multiply(A_inv, b, u);
    
    
    for (int i = 0; i < 3; i++)
        delete[] A_inv[i];
    delete[] A_inv;
}





// *** Internal functions - DEFINITION *** //


// Function to invert matrix M
// [result is stored in M_inv]

void invertMatrix(double **M, double **M_inv)
{
    // Declaring determinant
    double detM = 0;
    
    // Computing determinant with Sarrus rule
    for (int i = 0; i < 3; i++)
    {
        detM += M[0][i] * ( (M[1][(i+1)%3] * M[2][(i+2)%3]) - (M[1][(i+2)%3] * M[2][(i+1)%3]) );
    }
    
    // Computing inverse matrix (employing adjugate matrix)
    for (int i = 0; i < 3; i++)
    {
        for (int j = 0; j < 3; j++)
        {
            M_inv[i][j] = (1 / detM) * ( (M[(j+1)%3][(i+1)%3] * M[(j+2)%3][(i+2)%3]) - (M[(j+1)%3][(i+2)%3] * M[(j+2)%3][(i+1)%3]) );
        }
    }
}



// Function to multiply a matrix and a vector
void Multiply(double **C, double *d, double *res)
{
    for (int i = 0; i < 3; i++)
    {
        for (int k = 0; k < 3; k++)
            res[i] += C[i][k] * d[k];
    }
    
}
