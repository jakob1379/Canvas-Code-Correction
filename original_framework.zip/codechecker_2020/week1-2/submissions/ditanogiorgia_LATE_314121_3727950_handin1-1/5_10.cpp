//
//  5_10.cpp
//
//  Exercise 5.10
//

// *** DESCRIPTION *** //
// Module for solving a n × n linear system Au = b using
// Gaussian elimination with pivoting, where A is nonsingular.


#include "5_10.h"
#include <cmath>


// *** Internal functions - DECLARATION *** //


void swap_rows(double** M, int p, int q, int n);

int find_pivot(double** M, int n, int c, int k);

void red_to_ref(double** M, int n, double* b);

void back_sub(double** M, int n, double *b, double *u);





// *** Function to call the module - DEFINITION *** //


void guassian_elimination(double **A, double *b, double *u, int n)
{
    // Reducing A to row echeleon form
    red_to_ref(A, n, b);
    
    // Operating backward substitution to find unknown variables
    back_sub(A, n, b, u);
}





// *** Internal functions - DEFINITION *** //


// Function to swap two rows (p,q) of a matrix
// [n = dimension of the square matrix M]

void swap_rows(double** M, int p, int q, int n)
{
    double temp = 0;
    
    for (int i = 0; i < n; i++)
    {
        temp = M[p][i];
        M[p][i] = M[q][i];
        M[q][i] = temp;
    }
}



// Function to find the maximum among the leading coefficients
// of a given column - the function returns the index
// of the corresponding row
// (Pivoting)
//
// [n is the dimension of the square matrix M;
//  c is the index of the given column;
//  k is the number of rows already processed]

int find_pivot(double** M, int n, int c, int k)
{
    int i_piv = k; // row-index to return (initialization)
    
    for (int i = k + 1; i < n; i++)
        if ( fabs(M[i][c]) > fabs(M[i_piv][c]) )
            i_piv = i;
    
    return i_piv;
}



// Function to reduce a matrix in row echeleon form
// (Forward elimination)

void red_to_ref(double** M, int n, double* b)
{
    for (int k = 0; k < n; k++) // looping over cols
    {
        int i_piv;
        i_piv = find_pivot(M, n, k, k);
        
        if (i_piv != k)
        {
            swap_rows(M, i_piv, k, n);
            
            // Swap also corresponding elements of b
            double t = b[k];
            b[k] = b[i_piv];
            b[i_piv] = t;
        }
        
        for (int j = k + 1; j < n; j++)
        {
            double m = M[j][k] / M[k][k];
            // factor to set (j, k)-th element to zero
            
            for (int l = k; l < n; l++)
                M[j][l] -= M[k][l] * m;
            // subtraction of k-th row multiplied by m from j-th row
            
            b[j] -= b[k] * m;
            // subtraction of k-th b multiplied by m from j-th b
        }
    }
}




// Function to find solutions for any unknown variable,
// given that M is in row echeleon form
// (Back substitution)

// [n = dimension of square matrix M;
//  result is stored in u]

// Given that M is in row echeleon form, the following formula
// is used to compute the value of the r-th unknown variable:
// u[r] = ( 1 / M[r][r] ) * { b[r] - SUM_{i = r+1}^{n-1} of
//                                   [ (M[r][i] * u[i]) ] }

void back_sub(double** M, int n, double *b, double *u)
{
    double x = 0, sum = 0;
    
    for (int r = n - 1; r >= 0; r--) // Looping over rows, backwards
    {
        u[r] = b[r];
        
        for (int i = r + 1; i < n; i++)
            u[r] -= M[r][i] * u[i];
    
        u[r] = u[r] / M[r][r];
    }
}
