#include "3_3.h"
#include <iostream> //for using std::cout for printing
#include <fstream>
#include <cassert>

void implicit_Euler(int n){
    double h;
    std::cout << "Enter number of grid points: ";
    /*std::cin >> n; */
    assert(n>0);
    std::ofstream write_output("xy.dat");
    assert(write_output.is_open());
    h = 1./n; //do I need to convert N int to double?
    std::cout << "h = 1/"<<n<< " = " << h;
    int i;
    double x;
    double y_prev, y_next; 
    for(i=0;i<n;i++){
        
        x = (i)*h;

        if(i==0){
            y_next = 1;
            y_prev = 1;
        }

        else
        {
            y_next=(y_prev)/(h+1);
            y_prev = y_next;
        }
        write_output << x<<","<<y_next<<"\n";
    }


    write_output.close();
    return;
}