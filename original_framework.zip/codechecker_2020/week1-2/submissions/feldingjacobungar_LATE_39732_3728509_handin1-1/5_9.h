#ifndef H_5_10_H
#define H_5_10_H
#include "5_10.h" //to get multiply and matrix memory allocation functionality

void solve3by3(double **A, double *b, double *u);
void guassian_elimination(double **A, double *b, double *u, int n);
void DeepCopy(double** res, double** matrix, int rows,int cols);
void DeepCopy(double** res, double* vector, int n);

#endif
