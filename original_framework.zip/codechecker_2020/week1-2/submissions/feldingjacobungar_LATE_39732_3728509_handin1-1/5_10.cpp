#include "5_10.h"
#include <iostream>
#include <algorithm>
#include <cassert>
#include <cmath>
void guassian_elimination(double **A, double *b, double *u, int n)
{   
    double** P;
    P = AllocateMatrixMemory(n,n);
    double** A_temp;
    A_temp =  AllocateMatrixMemory(n,n);
    double* b_temp = new double [n];

    double** m;
    m = AllocateMatrixMemory(n,n);
    double** L;
    L = AllocateMatrixMemory(n,n);
    Identity(L,n,n);

    for (int k = 0; k<n; k++)
    {
        DeepCopy(A_temp,A,n,n);
        DeepCopy(b_temp,b,n);
        
        //See if diagonal element can be used as pivot
        //Find maximum row element in k'th column on or below diagonal of A:
        //int p = std::distance(A[k], std::max_element(A[k], A[k] + n))+k;
        double max_el = abs(A[k][k]);
        int p=k;
        for (int p_it=k;p_it<n-1;p_it++)
        {   
            if (abs(A[p_it][k])>max_el){p=p_it; max_el = abs(A[p_it][k]);}
            // this loop is instead of an argmax function...
        }

        assert(p>=k);   

        //Construct P matrix to switch row k and n
        
        if (p != k)
        {
            // Make permutation matrix to switch two rows
            for (int i=0;i<n;i++)
            {
                for (int j=0;j<n;j++)
                {
                    if ((i==j) && (i!=k) && (i!=p))
                    {
                        P[i][j]=1;
                    }
                    else if ((i==k) && (j == p))
                    {
                        P[i][j]=1;
                    }
                    else if ((i==p) && (j==k))
                    {
                        P[i][j]=1;
                    }
                    else
                    {
                        P[i][j]=0;
                    }
                }
            }
            

            //Replace matrix A by permuted matrix PA (if p!=k)
            Multiply(A, P, A_temp, n, n, n, n);
            //replace vector b by permuted vector Pb
            Multiply(b, P, b_temp, n, n, n);

            DeepCopy(A_temp,A,n,n);
            DeepCopy(b_temp,b,n);


        }
            
        if(A[k][k]!=0)
        {
            //triangularize after row permutation
            //Make m identity matrix initially
            Identity(m,n,n);

            //loop over lower triangular elements in columns of m
            for (int i=k+1;i<n;i++)
            {
                m[i][k] = -A[i][k]/A[k][k];
                L[i][k] = -m[i][k]; //these are columns of m_inverse
            }
            // Update A
            Multiply(A, m, A_temp, n, n, n, n);
        
        }
    }   
    double** U;
    // At this point U=A
    U = A;

    // Forwards substitution to obtain vector y in Ly=b as L is lower triangular;
    double* y = new double [n];
    for (int k=0; k<n;k++)
    {
        double dotprod = 0;
        for (int up_to_k=0;up_to_k<k;up_to_k++)
        {
            dotprod+=L[k][up_to_k]*y[up_to_k];
        }  
        y[k]=b[k]-dotprod;

    }


    // Back substitution to obtain solution vector u of Au=b

    for (int j=n-1;j>-1;j--){
        //counting down as U is upper triangular
        u[j] = y[j]/U[j][j];
        //update y
        for (int r=0;r<n-1;r++)
        {
            y[r] = y[r] - U[r][j]*u[j];
        }
    }
    
    delete[] y;    
    delete[] b_temp;
    
    FreeMatrixMemory(n,P);
    FreeMatrixMemory(n,A_temp);
    FreeMatrixMemory(n,m);
    FreeMatrixMemory(n,L);
    FreeMatrixMemory(n,U); //not sure I need to clear U when it is shallow copy of A
  
}

//Deep copy matrix
void DeepCopy(double** res, double** matrix, int rows,int cols)
   {
     
     for(int i=0; i<rows;i++)
     {
         for (int j=0; j<cols; j++)
         {
             res[i][j]=matrix[i][j];
         }
     }
   }

void DeepCopy(double* res , double* vector, int n)
{
    //Deep copy vector
    for(int i=0; i<n;i++)
    {
        res[i]=vector[i];
    }
}


// All from 5_6

void Multiply(double **res, double **A, double **B, int ARows, int ACols, int BRows, int BCols)
{
    //5.5. function to multiply two matrices A and B given also their sizes ARows, ACols and BRows, BCol
    //Must use assertions to verify that matrices can be multiplied
    assert(ACols == BRows);
    ResetElements(res,ARows,BCols);
    //Multiplication
    for (int i=0;i<ARows;i++)
    {
        for (int j=0;j<BCols;j++)
        {
            for(int n=0;n<ACols;n++)
            {
                res[i][j]+=A[i][n]*B[n][j];
            }
            
        }
    }


}

void Multiply(double *res, double *A, double **B, int ACols, int BRows, int BCols)
{
    //Overloading function to multiply vector A with matrix B
    //A is a row vector.
    //Matrix B must have same number of rows as (row vector) has columns
    assert(ACols=BRows);
    //res must be row vector 1xBCols //assert(res...)
    ResetElements(res,BCols);

    for (int i=0; i<BCols;i++)
    {
        for (int j=0; j<ACols;j++)
        {
            res[i]+=A[j]*B[j][i];
        }
    }


}

void Multiply(double *res, double **A, double *B, int ARows, int ACols, int BRows)
{
    //Overloading function to multiply Matrix A with vector B
    //B is a column vector.
    //Matrix A must have same number of columns as (column vector) has rows
    assert(ACols==BRows);
    //res must be row vector 1xACols 
    ResetElements(res,ACols);

    for (int i=0; i<ARows;i++)
    {
        for (int j=0; j<ACols;j++)
        {
            res[i]+=A[i][j]*B[j];
        }
    }

}


void Multiply(double **res, double scalar, double **B, int BRows, int BCols)
{
    // Multiply scalar with matrix
    ResetElements(res,BRows,BCols);

    for (int i=0; i<BRows;i++)
    {
        for (int j=0; j<BCols;j++)
        {
            res[i][j]=scalar*B[i][j];
        }
    }

}

void Multiply(double **res, double **B, double scalar, int BRows, int BCols)
{   
    
    // Multiply scalar with matrix
    ResetElements(res,BRows,BCols);

    for (int i=0; i<BRows;i++)
    {
        for (int j=0; j<BCols;j++)
        {
            res[i][j]=scalar*B[i][j];
        }
    }

}

void ResetElements(double** res, int rows, int cols)
{
    //clear resulting matrix to make sure that += for matrix 
    //multiplication does not add to existing values in res
    for (int i=0;i<rows;i++)
    {
        for (int j=0;j<cols;j++)
        {
            res[i][j]=0;
        }
    }
}
void ResetElements(double* res, int n)
{
    //clear resulting matrix to make sure that += for matrix 
    //multiplication does not add to existing values in res
    for (int i=0;i<n;i++)
    {
        res[i]=0;
    }

}

void Identity(double** res, int rows, int cols)
{
    //clear resulting matrix to make sure that += for matrix 
    //multiplication does not add to existing values in res
    for (int i=0;i<rows;i++)
    {
        for (int j=0;j<cols;j++)
        {   
            if(i==j)
            {
                res[i][j]=1;
            }
            else
            {
                res[i][j]=0;
            }
        }
    }
}

double** AllocateMatrixMemory(int numRows, int numCols)
{
	double** matrix;
	matrix = new double* [numRows];
	for (int i=0; i<numRows; i++)
	{
		matrix[i] = new double [numCols];
	}
	return matrix;
}

//Free matrix memory again
void FreeMatrixMemory(int numRows, double** matrix)
{
	for (int i=0; i<numRows; i++)
	{
		delete[] matrix[i];
	}
	delete[] matrix;
}