#include "5_4.h"
#include <cassert>
#include <cmath>

double calc_std(double a[], int length){
double sigma=0, mean=0;
if(length>1){
    for(int i=0;i<length;i++){
        mean+=a[i];
    }
    mean=mean/length;
    for(int i=0;i<length;i++){
        sigma+=pow(a[i]-mean,2);
    }
    sigma=sqrt(sigma/(length-1));
} else{
    sigma=0;
}
return sigma;
}//end of std function

double calc_mean(double a[], int length){
double mean=0;
for(int i=0;i<length;i++){
    mean+=a[i];
}
mean=mean/length;
return mean;
}//end of mean function