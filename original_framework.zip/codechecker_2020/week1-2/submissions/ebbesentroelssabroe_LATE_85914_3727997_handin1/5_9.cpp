#include "5_9.h"

void solve3by3(double **A, double *b, double *u){
    //we do not check det(A)!=0 since we assume nonsingular matrix
    int n=3;
    double **Gaus=new double* [n];
    for(int i=0;i<n;i++){
        Gaus[i] = new double [n+1];
    }

    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            Gaus[i][j]=A[i][j];
        }
    }
    for(int i=0;i<n;i++){
        Gaus[i][n]=b[i];
    }
    for(int i=0;i<n;i++){//get zeros in lower triangle
        if(Gaus[i][i]==0){//zwitch rows if 0 in i'th diagonal.
            for(int j=i;j<n;j++){
                if(Gaus[i][j]!=0){
                    int row=j;
                    double temp;
                    int k=0;
                    for(int l=i;l<(n+1);l++){
                        temp=Gaus[i][l];
                        k++;
                        Gaus[i][l]=Gaus[row][l];
                        Gaus[row][l]=temp;
                    }
                    break;
                }
            }
        }
        double dia_val=Gaus[i][i];
        for(int j=0;j<(n+1);j++){//we get a 1 in the diagonal
            Gaus[i][j]/=dia_val;
        }
        for(int k=(i+1);k<n;k++){//we get zeros below the diagonal
            double below_dia=Gaus[k][i];
            for(int j=i;j<(n+1);j++){
                Gaus[k][j]-=below_dia*Gaus[i][j];
            }
        }
    }
    for(int j=(n-1);j>=0;j--){//we get zeros in upper triangle
        for(int i=(j-1);i>=0;i--){
            double above_one=Gaus[i][j];
            Gaus[i][n]-=Gaus[j][n]*above_one;
            Gaus[i][j]-=Gaus[j][j]*above_one;
        }
    }
    for(int i=0;i<n;i++){//writing result to u
        u[i]=Gaus[i][n];
    }
    for(int i=0;i<n;i++){
        delete[] Gaus[i];
    }
    delete[] Gaus;
}