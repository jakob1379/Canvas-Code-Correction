#include "2_6.h"
#include <cmath> 
double newton_Raphson(double initialGuess, double epsilon){
    double x_prev, x_next=initialGuess ;
    int i=0;
    double diff;
    do{
        i++;
        x_prev=x_next;
        x_next=x_prev-(exp(x_prev)+pow(x_prev,3)-5)/(exp(x_prev)+3*pow(x_prev,2));
        diff=fabs(x_next-x_prev);
    } while(diff>epsilon);
    return x_next ;
}



