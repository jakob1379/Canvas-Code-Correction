#include "3_3.h"
#include <iostream>
#include <cassert>
#include <fstream>
void implicit_Euler(int n){
    assert(n>1);
    double h=1/((double)(n));
    double* x;
    double* y;
    x= new double [n];
    y= new double [n];
    y[0]=1;
    x[0]=0;
    std::ofstream write_output("xy.dat");
    assert(write_output.is_open());
    write_output << x[0] << "," << y[0] << "\n";
    for(int i=1;i<n;i++){
        x[i]=((double)(i))*h;
        y[i]=y[i-1]-y[i-1]*h;
        write_output << x[i] << "," << y[i] <<"\n";
    }
    write_output.close();
    delete[] x;
    delete[] y;
}