#include <iostream>
#include "5_9.h"
#include <cmath>
#include <cassert>
#include <fstream>

void solve3by3 ( double **A, double *b , double *u)
{
	double matrix[3][3];
	double matrixminusforste[3][3];

	for (int index_1 = 0; index_1<3; index_1++)
	{
        	for (int index_2 = 0; index_2<3; index_2++)
		{
            		matrix[index_1][index_2] = A[index_1][index_2];
        	}
	}
	
	matrixminusforste[0][0]=matrix[1][1]*matrix[2][2]-matrix[1][2]*matrix[2][1];
	matrixminusforste[0][1]=matrix[0][2]*matrix[2][1]-matrix[0][1]*matrix[2][2];
	matrixminusforste[0][2]=matrix[0][1]*matrix[1][2]-matrix[0][2]*matrix[1][1];
	matrixminusforste[1][0]=matrix[1][2]*matrix[2][0]-matrix[1][0]*matrix[2][2];
	matrixminusforste[1][1]=matrix[0][0]*matrix[2][2]-matrix[0][2]*matrix[2][0];
	matrixminusforste[1][2]=matrix[0][2]*matrix[1][0]-matrix[0][0]*matrix[1][2];
	matrixminusforste[2][0]=matrix[1][0]*matrix[2][1]-matrix[1][1]*matrix[2][0];
	matrixminusforste[2][1]=matrix[0][1]*matrix[2][0]-matrix[0][0]*matrix[2][1];
	matrixminusforste[2][2]=matrix[0][0]*matrix[1][1]-matrix[1][0]*matrix[0][1];
	
	double determinanten;
	determinanten=matrix[0][0]*(matrix[1][1]*matrix[2][2]-matrix[1][2]*matrix[2][1])-			matrix[0][1]*(matrix[1][0]*matrix[2][2]-matrix[1][2]*matrix[2][0])
			+matrix[0][2]*(matrix[1][0]*matrix[2][1]-matrix[1][1]*matrix[2][0]);


	for(int i=0; i<3; i++) 
	{
		
		for(int j=0; j<3; j++) 
		{
			u[i] += (matrixminusforste[i][j]/determinanten)*b[j];
		}
	}
}
	
