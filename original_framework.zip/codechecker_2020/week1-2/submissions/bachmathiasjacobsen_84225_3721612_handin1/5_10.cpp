#include <iostream>
#include "5_10.h"
#include <cmath>
#include <cassert>
#include <fstream>

void guassian_elimination(double **A, double *b, double *u, int n)
{
    
    int index_1;
    int index_2;
    int index_3;
    int index_4;
    int index_5;
    int index_6;
    int index_7;

    for (index_1=0; index_1<n; index_1++)
    {
        double pivotmaks;
        pivotmaks=0;
        for (index_2=index_1; index_2<n; index_2++)
        {
            double maksraekke;
            double andenraekke;
            andenraekke=std::abs(A[index_2][index_1]);
            maksraekke=std::abs(pivotmaks);
            if (andenraekke>maksraekke)
            {
                pivotmaks=A[index_2][index_1];
                double bytterundt[n];
                for (index_3=0; index_3<n; index_3++)
                {
                    bytterundt[index_3]=A[index_1][index_3];
                    A[index_1][index_3]=A[index_2][index_3];
                    A[index_2][index_3]=bytterundt[index_3];
                }
                double bytterundt2;
                bytterundt2=b[index_1];
                b[index_1]=b[index_2];
                b[index_2]=bytterundt2;
        }
        }
        for (index_4=(index_1+1); index_4<n; index_4++)
        {
            double multrownul;
            multrownul=A[index_4][index_1]/pivotmaks;
            b[index_4]=b[index_4]-b[index_1]*multrownul;
            
            for (index_5=0; index_5<n; index_5++)
            {
                A[index_4][index_5]=A[index_4][index_5]-A[index_1][index_5]*multrownul;}
        }
        
    }
    for (index_6 = n-1; index_6>=0; index_6--){
        double linearkomb = 0;
        for (index_7 = index_6+1; index_7< n; index_7++){
            linearkomb += A[index_6][index_7]*u[index_7];}
        u[index_6] = (b[index_6] - linearkomb)/A[index_6][index_6];}
        }
                
                
                
        
