#include <iostream>
#include "3_3.h"
#include <cmath>
#include <cassert>
#include <fstream>

void implicit_Euler(int n)
{
	double gridpointss=n;
	double h=1/gridpointss;
	int gridpoints=n;
	assert(gridpoints>1);
		double x[gridpoints];
		double y[gridpoints];
		y[0]=1;
		x[0]=0;


		for(int i=1; i<gridpoints; i++){

			y[i]=y[i-1]/(1+h);
			x[i]=h*i;
		}

		std::ofstream MyFile("xy.dat");
		for(int i=0; i<gridpoints; i++){
			
			MyFile << x[i] << "," << y[i] << "\n";
		}
	
}
