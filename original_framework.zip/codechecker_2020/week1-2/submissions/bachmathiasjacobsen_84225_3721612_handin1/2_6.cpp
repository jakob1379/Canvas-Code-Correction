#include <iostream>
#include "2_6.h"
#include <cmath>


double newton_Raphson(double initialGuess, double epsilon){

	double x=initialGuess;
	double fraction=(exp(x)+x*x*x-5)/(exp(x)+3*x*x);
	double y=x-fraction;
	double distance = 100000+epsilon;
	
	while (fabs(distance)>epsilon) 
	{
		distance=(exp(x)+x*x*x-5)/(exp(x)+3*x*x);
		x=x-distance;
	} 
	return x;
}
		
		
		



