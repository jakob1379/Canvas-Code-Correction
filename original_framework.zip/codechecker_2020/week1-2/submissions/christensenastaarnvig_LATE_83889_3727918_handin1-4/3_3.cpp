//
//  3_3.cpp
//  HandIn1
//
//  Created by Asta Christensen on 27/04/2020.
//  Copyright © 2020 Asta Christensen. All rights reserved.
//

#include "3_3.h"
#include <iostream>
#include <cmath>
#include <fstream>
#include <cassert>
#include <cstdlib>

void implicit_Euler(int n){
    

    std::ofstream write_output("xy.dat"); //Creating empty datafile
    assert(write_output.is_open());
    
    assert(n > 1); //We want more the 1 grid point
    double h = 1.0/((double) (n)); //Let h = 1/N
    
    double y[n]; //Defining y as a vector of lenght n
    y[0]= 1.0; //The initial value of y
    double x[n]; //Defining x as a vector of lenght n
    x[0]= 0.0; //The initial value of x, since x(0)=0*h
    
    for (int i = 1; i <= n; i++){
        x[i] = ((double) (i))*h;
        y[i] = y[i-1]/(h + 1.0);
    }
    for (int i = 0; i <= n; i++){
        write_output << x[i] << "," << y[i] << "\n";
    } //Writes the output of the previous for loop into the data file and the initial values
    
    write_output.close();

    write_output.flush();

}
