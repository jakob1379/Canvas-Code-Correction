//
//  5_4.cpp
//  HandIn1
//
//  Created by Asta Christensen on 29/04/2020.
//  Copyright © 2020 Asta Christensen. All rights reserved.
//

#include "5_4.h"
#include <iostream>
#include <cmath>
#include <fstream>
#include <cassert>
#include <cstdlib>

double calc_mean(double a[], int length){
    
    double sum, mean;
    
    sum = 0;
    
    for(int i = 0; i < length; i++){
        sum += a[i];
    }
    
    mean = (1.0/length)*sum;
    
    return mean;
}


double calc_std(double a[], int length){
        
    double sum, sigma, mean, b[length];
    
    sum = 0;
    
    mean = calc_mean(a, length);
    
    if(length > 1)
    {
        for(int i = 0; i < length; i++)
        {
            b[i] = pow((a[i]-mean),2);
            sum += b[i];
        }
        
        sigma = sqrt(sum/(length-1.0));
        
        return sigma;

    }
    else
    {
        return 0;
    }

}
