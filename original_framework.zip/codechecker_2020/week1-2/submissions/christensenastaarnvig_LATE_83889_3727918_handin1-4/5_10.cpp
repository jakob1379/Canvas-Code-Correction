//
//  5_10.cpp
//  HandIn1
//
//  Created by Asta Christensen on 03/05/2020.
//  Copyright © 2020 Asta Christensen. All rights reserved.
//

#include "5_10.h"
#include <iostream>
#include <cmath>





static void swap_rows(int row1, int row2, double **A, int n);

static void swap_rows_result(int row1, int row2, double *b, int n);

static void pivot(double **A, double *b, int n, int j);

// Swaps rows in the matrix A

void swap_rows(int row1, int row2, double **A, int n){
    double temp;
    
    for(int j = 0; j < n; j++)
    {
        temp = A[row1][j];
        A[row1][j] = A[row2][j];
        A[row2][j] = temp;
    }
}

// Swaps rows in the vector b
void swap_rows_result(int row1, int row2, double *b, int n){
    double temp;
    
    temp = b[row1];
    b[row1] = b[row2];
    b[row2] = temp;
    
}

//Pivoting

void pivot(double **A, double *b, int n, int j){
    double epsilon = 0.0001;
    
    if(fabs(A[j][j]) <= epsilon){
        int max_position = j;
        for(int i = j+1; i < n; i++)
        {
            if(fabs(A[i][j])>fabs(A[max_position][j]))
            {
                max_position = i;
            }
        }
        swap_rows(max_position, j, A, n);
        swap_rows_result(max_position, j, b, n);
    }
}



void guassian_elimination(double **A, double *b, double *u, int n){
    
    //Runs through the columns
    for(int j = 0; j < n; j++){
        pivot(A, b, n, j); //Makes sures that we have a pivot after each iteration
        //creates a factor, which makes the diagonal 1
        double factor = 1/A[j][j];
        
        for(int i = j; i < n; i++){
            A[j][i] = factor*A[j][i]; //multyplies all rownumbers with factor in the matrix
        }
        b[j] = factor*b[j]; //multyplies alle rows in b with the factor
        
        for(int i=j+1; i < n; i++){
            double factor_2 = A[i][j]; //Finds the factor of which we need to subtrct to get 0 in the row below
            
            for(int k = 0; k < n; k++){
                A[i][k] -= factor_2*A[j][k]; //Subtracts this number of rows from the matrix A, to get the 0
            }
            b[i] -= factor_2*b[j]; //Substracts from the vector b as well
        }
        
    }
    
    //At last we do the Backward substitution
        
    u[n-1]=b[n-1]/A[n-1][n-1];
    
    for(int i = n-2; i >= 0; i--){
        double sum = b[i];
        for(int j=i+1; j < n; j++){
            sum -= A[i][j]*u[j];
        }
        u[i] = sum/A[i][i];
    }
    
}
