//
//  2_6.cpp
//  HandIn1
//
//  Created by Asta Christensen on 22/04/2020.
//  Copyright © 2020 Asta Christensen. All rights reserved.
//

#include "2_6.h"
#include <iostream>
#include <cmath>

double newton_Raphson(double initialGuess, double epsilon){
    
    double x_prev = initialGuess;
    double x_next=0.0;
    
    
    double f_x, df_x;
    bool convergetest = true;
    
    while(convergetest){
        f_x = exp(x_prev)+pow(x_prev, 3) - 5; //Defining f(x)
        df_x = exp(x_prev)+3*pow(x_prev, 2); // Defining f'(x)
        
        x_next = x_prev - f_x/df_x; //Calculating x_next
        
        convergetest = (fabs(x_prev-x_next)>epsilon);
        // the test is true, if it isn't converging
        x_prev = x_next; //Storing new value of x
    }
    return x_next;
    
}
