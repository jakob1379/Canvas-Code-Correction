//
//  5_3.cpp
//  HandIn1
//
//  Created by Asta Christensen on 29/04/2020.
//  Copyright © 2020 Asta Christensen. All rights reserved.
//

#include "5_3.h"
#include <iostream>
#include <cmath>
#include <fstream>
#include <cassert>
#include <cstdlib>


void swap_pointer(double *a, double *b){
    
    double value_a;
    
    value_a = *a;
    
    *a = *b;
    
    *b = value_a;
    
    return;
}

void swap_ref(double &a, double &b){
    
    double *p_a, *p_b, *p_c, *p_d;
    
    p_a = &a;
    p_b = &b;
    
    p_c = new double;
    p_d = new double;
    
    *p_c = a;
    *p_d = b;
    
    a = *p_b;
    
    *p_b = *p_c;
    b = *p_b;
    
    return;
}

