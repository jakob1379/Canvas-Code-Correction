//
//  5_9.cpp
//  HandIn1
//
//  Created by Asta Christensen on 02/05/2020.
//  Copyright © 2020 Asta Christensen. All rights reserved.
//

#include "5_9.h"
#include <iostream>
#include <cmath>
#include <fstream>
#include <cassert>
#include <cstdlib>


void solve3by3(double **A, double *b, double *u){
    
    double **inverseA;
    double detA;
    
    inverseA = new double* [3];
    for (int i=0; i<3; i++)
    {
        inverseA[i] = new double [3];
    }
    
    detA = A[0][0]*(A[1][1]*A[2][2]-A[1][2]*A[2][1])
            -A[0][1]*(A[1][0]*A[2][2]-A[1][2]*A[2][0])
            +A[0][2]*(A[1][0]*A[2][1]-A[1][1]*A[2][0]);
    
    assert(detA!=0);
    
    inverseA[0][0] = 1/detA * (A[1][1]*A[2][2]-A[1][2]*A[2][1]);
    inverseA[0][1] = 1/detA * (A[0][2]*A[2][1]-A[0][1]*A[2][2]);
    inverseA[0][2] = 1/detA * (A[0][1]*A[1][2]-A[1][1]*A[0][2]);
    
    inverseA[1][0] = 1/detA * (A[1][2]*A[2][0]-A[1][0]*A[2][2]);
    inverseA[1][1] = 1/detA * (A[0][0]*A[2][2]-A[0][2]*A[2][0]);
    inverseA[1][2] = 1/detA * (A[0][2]*A[1][0]-A[0][0]*A[1][2]);
    
    inverseA[2][0] = 1/detA * (A[1][0]*A[2][1]-A[1][1]*A[2][0]);
    inverseA[2][1] = 1/detA * (A[0][1]*A[2][0]-A[0][0]*A[2][1]);
    inverseA[2][2] = 1/detA * (A[0][0]*A[1][1]-A[1][0]*A[0][1]);

    
    for(int i = 0; i < 3; i++){
        for(int j = 0; j < 3; j++){
            u[i] += inverseA[i][j]*b[j];
        }
    }
    
    for (int i=0; i<3; i++)
    {
        delete[] inverseA[i];
    }
    delete[] inverseA;
    
}
