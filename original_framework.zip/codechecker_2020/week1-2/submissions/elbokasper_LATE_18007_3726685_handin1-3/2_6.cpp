#include "2_6.h"
#include <cfloat>
#include <cmath>

double func(double x){
  return exp(x) + pow(x, 3) - 5;
}

double func_diff(double x){
  return exp(x) + 3 * pow(x, 2);
}

double newton_Raphson(double initialGuess, double epsilon)
{
    double x_prev = initialGuess;
    double x_next = x_prev - func(x_prev)/func_diff(x_prev);
    while(std::abs(x_next - x_prev) > epsilon){
        x_prev = x_next;
        x_next = x_prev - func(x_prev)/func_diff(x_prev);
    }
    return x_next;
}
