#include "5_9.h"

double determinant(double** A){
  double det = 0;
  for(int i = 0; i < 3; i++){
    det = det + (A[0][i]*(A[1][(i+1)%3]*A[2][(i+2)%3]-A[1][(i+2)%3]*A[2][(i+1)%3]));
  }
  return det;
}

void create_matrix(double** A, double** T, double* b, int col){
  for(int i = 0; i<3; i++){
    for(int j = 0; j<3; j++){
      if(j == col){
        T[i][j] = b[i];
      } else{
        T[i][j] = A[i][j];
      }
    }
  }
}

void solve3by3(double** A, double *b, double *u){
  double det = determinant(A);
  double** T = new double*[3];
  for(int i = 0; i < 3; i++){
    T[i] = new double[3];
  }
  for(int i = 0; i<3; i++){
    create_matrix(A, T, b, i);
    double d = determinant(T);
    u[i] = d/det;
  }

  for(int i = 0; i < 3; i++){
    delete[] T[i];
  }
  delete[] T;
}
