#include "3_3.h"

#include <cassert>
#include <fstream>
#include <iostream>

void implicit_Euler(int n){
  assert(n > 1);
  double iterations = n-1;
  double h = 1 / iterations;
  double *y = new double[n];
  double x = 0;
  y[0] = 1;

  std::ofstream write_output;
  write_output.open("xy.dat");
  assert(write_output.is_open());
  write_output << x << "," << y[0] << std::endl;

  for(int i = 1; i < n; i++){
    x = i*h;
    y[i] = y[i-1]/(h+1);
    write_output << x << "," << y[i] << std::endl;
  }
   write_output.close();

   delete[] y;
}
