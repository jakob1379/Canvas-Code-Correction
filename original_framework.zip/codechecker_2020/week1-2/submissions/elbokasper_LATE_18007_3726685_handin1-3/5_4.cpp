#include "5_4.h"

#include <cmath>

double calc_mean(double a[], int length){
  double sum = 0;
  for(int i = 0; i < length; i++){
    sum += a[i];
  }
  return sum / length;
}

double calc_std(double a[], int length){
  if(length == 1){
    return 0;
  }
  double sum = 0;
  double mean = calc_mean(a, length);
  for(int i = 0; i < length; i++){
    sum += std::pow(a[i] - mean, 2);
  }
  sum /= (length-1);
  return std::sqrt(sum);
}
