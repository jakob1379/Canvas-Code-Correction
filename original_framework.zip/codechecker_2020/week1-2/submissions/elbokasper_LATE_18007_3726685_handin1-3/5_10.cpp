#include "5_10.h"

#include <cmath>

void row_exchange(double **A, int i, int j, int n){
  double *temp = A[i];
  A[i] = A[j];
  A[j] = temp;
}

void row_multiply(double **A, int i, double factor, int n){
  for(int j = 0; j <= n; j++){
    A[i][j] = factor * A[i][j];
  }
}

void row_add(double **A, int i, int j, double factor, int n){
  for(int k = 0; k <= n; k++){
    A[j][k] += factor * A[i][k];
  }
}

void create_augmented(double **A, double *b, double **B, int n){
  for(int i = 0; i < n; i++){
    for(int j = 0; j <= n; j++){
      if(j == n){
        B[i][j] = b[i];
      } else {
        B[i][j] = A[i][j];
      }
    }
  }
}

void guassian_elimination(double **A, double *b, double *u, int n){
  double **B = new double* [n];
  for(int i = 0; i < n; i++){
    B[i] = new double[n+1];
  }
  create_augmented(A, b, B, n);

  // for each column in the augmented matrix excluding the last
  for(int i = 0; i < n; i++){
    // find largest absolute valued element in column
    int maxElem = i;
    for(int j = i+1; j < n; j++){
      if(std::abs(B[j][i]) > std::abs(B[maxElem][i])){
        maxElem = j;
      }
    }
    // if max element is not in ith row, then exchange
    if(maxElem != i){
      row_exchange(B, i, maxElem, n);
    }
    // Eliminate rows below ith row
    for(int j = i+1; j < n; j++){
      row_add(B, i, j, -B[j][i]/B[i][i], n);
    }
    // If pivot != 1 then multiply by 1/value
    if(B[i][i] != 1){
      row_multiply(B, i, 1/B[i][i], n);
    }
    // backwards reduce
    for(int k = i-1; k >= 0; k--){
      if(B[k][i] != 0){
        row_add(B, i, k, -B[k][i], n);
      }
    }
  }
  
  for(int i = 0; i < n; i++){
    u[i] = B[i][n];
    delete[] B[i];
  }
  delete[] B;
}
