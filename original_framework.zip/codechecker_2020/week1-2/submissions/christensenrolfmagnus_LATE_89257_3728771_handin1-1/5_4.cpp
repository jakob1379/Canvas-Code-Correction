#include "5_4.h"
#include <iostream>
#include <cmath>

double calc_std(double a[], int length)
{
    double mean = calc_mean(a, length);
    std::cout<<"mean = ";
    std::cout<< mean;
    std::cout<<"\n\n";
    
    double sum_x = 0;
    
    for (int i=0; i<length; i++)
    {
        sum_x += pow((a[i]-mean),2);
    }
    
    
    double std_dev = sqrt(sum_x / (length-1));
    
    std::cout<<"std_dev = ";
    std::cout<< std_dev;
    std::cout<<"\n\n";

    return std_dev;
}

double calc_mean(double a[], int length)
{
    double sum = 0;

    for (int i=0; i<length; i++)
    {
        sum += a[i];
        std::cout<< sum;
        std::cout<<"\n";
    }

    return sum/length;
}