#include "5_10.h"
#include <iostream>
#include <cmath>
#include <cassert>

void guassian_elimination(double **A, double *b, double *u, int n)
{

    double** P;

    P = new double* [n];

    for(int i=0; i<n; i++)
    {
        P[i] = new double[n];
    }

    double** temp_A;
    // create a temporary matrix for pivoted values in matrix A

    temp_A = new double* [n];

    for(int i=0; i<n; i++)
    {
        temp_A[i] = new double[n];
    }
    
    double* temp_b;
    // create a temporary matrix for pivoted values in matrix b

    temp_b = new double[n];

    for(int i=0; i<n; i++)
    // initialize P to zero
    {
        for(int k=0; k<n; k++)
        {
            P[i][k] = 0;
        }
    }

    for(int i=0; i<n; i++)
    // initialize temp_A to zero
    {
        for(int k=0; k<n; k++)
        {
            temp_A[i][k] = 0;
        }
    }

 for(int k=0; k<(n-1); k++)
    // Gaussian elimination
    {
        int max_val = 0;

        for (int row=0; row<n; row++)
        // find the row with the highest absolute value of A[n][k]
        {
            if (fabs(A[row][k]) > fabs(A[max_val][k]))
            {
                max_val = row;
            }
        }

        for(int x=0; x<n; x++)
        //Fill out matrix P with 0 and 1's
        {
            for(int y=0; y<n; y++)
            {
                if((x==y) && (y != k) && (x != k) && (y != max_val) && (x != max_val))
                {
                    P[x][y] = 1;
                }
                else if((x == k) && (y == max_val))
                {
                        P[x][y] = 1;
                }
                else if((x==max_val) && (y==k))
                {
                    P[x][y] = 1;
                }
                else
                {
                    P[x][y] = 0;
                }
            }
        }

    for(int I=0; I<n; I++)
    //take dot product of P and A and assign the values to temp 
    {
        for(int X=0; X<n; X++)
        {
        double sum = 0;
            for(int Y=0; Y<n; Y++)
            {
                sum += (P[I][Y] * A[Y][X]);
            }
        temp_A[I][X] = sum;
        }
    }

    for(int row=0; row<n; row++)
    //assign pivoted values from temp_A to A
    {
        for(int col=0; col<n; col++)
        {
            A[row][col] = temp_A[row][col];
        }
    }

        for(int i=0; i<n; i++)
        //take dot product of B and P (pivoting the matrix)
        {
            double sum = 0;
            for (int x=0; x<n; x++)
            {
                sum += (P[i][x] * b[x]);
            }
            temp_b[i] = sum;
        }


        for(int row=0; row<n; row++)
        //assign pivoted values from temp_b to b
        {
                b[row] = temp_b[row];
        }     

        for(int i =(k+1); i<n; i++)
        {    
            // find suitable multiple
            double m = A[i][k]/A[k][k];

            for(int j=0; j <= n; j++)
            {
                A[i][j] -= m * A[k][j];
            }
            b[i] = b[i] - m*b[k];
        }
    }
        
    
    for(int i=0; i<n; i++)
    {
        delete[] temp_A[i];
    }
    delete[] temp_A;    


    delete[] temp_b;    
    
    for(int i=0; i<n; i++)
    {
        delete[] P[i];
    }
    delete[] P;

//assign value u[n-1]
u[n-1] = b[n-1] / A[n-1][n-1];

for(int k=(n-2); k >= 0; k--)
// compute back-substitution
{
    double sum = 0;
    for(int i=(k+1); i<n; i++)
    {
        sum += A[k][i] * u[i];
    }
    u[k] = (b[k] - sum) / A[k][k];
}
}
