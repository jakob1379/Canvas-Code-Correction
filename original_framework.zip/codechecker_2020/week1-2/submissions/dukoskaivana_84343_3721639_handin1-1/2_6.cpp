#include<iostream>
#include<cmath>
#include"2_6.h"

//double newton_Raphson(double initialGuess, double epsilon){
//	double x[100];
//	int i = 0;
//	x[0] = initialGuess;
//	for ( i = 1; i < 100; i++)
//	{
//		x[i] = x[i - 1] - (exp(x[i-1]) + pow(x[i - 1], 3) - 5) / (exp(x[i - 1]) + 3 * pow(x[i - 1], 2));
//		std::cout << x[i] << "\n" << exp(x[i]) + pow(x[i], 3) - 5 << "\n";
//	}
//	return 0;
//}

double newton_Raphson(double initialGuess, double epsilon) {
    double x_prev, x_next, update_;
    x_prev = initialGuess;
    x_next = x_prev + epsilon;
    update_ = 10000;
    int i;
    while (fabs(x_next - x_prev) >= epsilon) {
        if (update_ != 10000)
        {
            x_prev = update_;
        }
        x_next = x_prev - (exp(x_prev) + pow(x_prev, 3) - 5) / (exp(x_prev) + 3 * pow(x_prev, 2));
        update_ = x_next;
    }
    return x_next;
}