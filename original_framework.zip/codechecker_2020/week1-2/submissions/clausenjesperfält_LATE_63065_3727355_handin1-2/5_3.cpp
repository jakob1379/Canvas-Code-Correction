#include "5_3.h"
#include <algorithm> 

void swap_pointer(double *a, double *b) {
    *a += *b;
    *b = *a - *b;
    *a -= *b; 
}

void swap_ref(double &a, double &b) {
    // C++
    std::swap(a,b);

    //// General C
    // double tmp = a;
    // a = b;
    // b = tmp;
}