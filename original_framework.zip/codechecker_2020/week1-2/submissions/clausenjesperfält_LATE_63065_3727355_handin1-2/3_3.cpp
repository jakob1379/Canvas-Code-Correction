#include "3_3.h"
#include <math.h>
#include <iostream>
#include <fstream>
#include <cassert>

void implicit_Euler(int n) {
    assert(n>1);

    double h_step = 1.0 / n;
    int i = 0;
    double y_cur, y_prev = 1;

    std::ofstream write_file("xy.dat");
    write_file.precision(13);

    do
    {
        i++;

        y_cur = (y_prev/(1+h_step));

        write_file << (i*h_step) << " " << y_cur <<"\n";

        y_prev = y_cur;
    } while (i < n);

    write_file.close();
}