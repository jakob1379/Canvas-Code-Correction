#include "5_6.h"
#include <assert.h>

void Multiply(double **res, double **A, double **B, int ARows, int ACols, int BRows, int BCols) {
    
    assert(ACols == BRows);
    
    for (short i = 0; i < ARows; i++)
    {
        for (short j = 0; j < BCols; j++)
        {
            res[i][j] = 0.0;
            for (short k = 0; k < ACols; k++)
            {
                res[i][j] += A[i][k] * B[k][j];
            }
        }
    }
}

// This operation does not exist as vector*Matrix
// but I assume an Array or transposed vector is meant
void Multiply(double *res, double *A, double **B, int ACols, int BRows, int BCols) {
    assert(ACols == BRows);

    for (short i = 0; i < BRows; i++) {
        res[i] = 0.0;
        for (short k = 0; k < ACols; k++) {
            res[i] += A[k] * B[k][i];
        }
    }
}

void Multiply(double *res, double **A, double *B, int ARows, int ACols, int BRows) {
    assert(ACols == BRows);
    
    for (short i = 0; i < ARows; i++)
    {
        res[i] = 0.0;
        for (short k = 0; k < ACols; k++)
        {
            res[i] += A[i][k] * B[k];
        }
    }
}

void Multiply(double **res, double scalar, double **B, int BRows, int BCols) {
    for (short i = 0; i < BRows; i++)
    {
        for (short j = 0; j < BCols; j++)
        {
            res[i][j] = scalar * B[i][j];
        }
    }
}

// Since we only use Doubles are left and right multiplication the same
void Multiply(double **res, double **B, double scalar, int BRows, int BCols) {
    Multiply(res, scalar, B, BRows, BCols);
}