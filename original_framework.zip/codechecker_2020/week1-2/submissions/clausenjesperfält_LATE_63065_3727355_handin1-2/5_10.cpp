#include "5_10.h"


void row_echelon_form(double **A, double *b, double *u, int n) {
    double p, o;
    for (short r = 0; r < n; r++)
    {
        for (short c = 0; c < r+1; c++)
        {
            p = A[r][c];
            
            // Do action on row
            for (short i = c; i < n; i++)
            {
                if (r == c) 
                {
                    A[r][i] /= p;
                } 
                else 
                {
                    A[r][i] -= A[c][i]*p;
                }    
            }
            // Do action on b
            if (r == c) 
            {
                b[r] /= p;
            }
            else 
            {
                b[r] -= b[c]*p;
            }
        }
    }
}

void backwards_substitution(double **A, double *b, double *u, int n) {
    // Move b values into u
    for (short r = 0; r < n; r++)
    {
        u[r] = b[r];
    }
    

    for (short r = n-1; r >= 0; r--)
    {
        for (short c = n-1; c > r; c--)
        {
            u[r] -= A[r][c] * u[c];
        }        
    }
    
}

void guassian_elimination(double **A, double *b, double *u, int n) {
    row_echelon_form(A, b, u, n);
    backwards_substitution(A, b, u, n); 
}