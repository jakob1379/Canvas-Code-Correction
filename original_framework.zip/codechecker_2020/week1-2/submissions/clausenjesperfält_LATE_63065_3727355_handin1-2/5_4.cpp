#include "5_4.h"
#include <numeric>
#include <cmath>
#include <functional>
#include <algorithm>

double calc_std(double a[], int length) {
    double var = 0.0;
    double mean = calc_mean(a, length);

    for (short i = 0; i < length; i++)
    {
        var += std::pow(a[i]-mean,2);
    } 
    
    if (length == 1) {
        return 0;
    }

    return std::sqrt(var / (length - 1));
}

double calc_mean(double a[], int length) {
    return std::accumulate(a, a+length, 0.0, std::plus<double>())/length;
}

