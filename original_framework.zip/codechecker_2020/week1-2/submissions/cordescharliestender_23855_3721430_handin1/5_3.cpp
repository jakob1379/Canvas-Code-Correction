#include "5_3.h"
#include <iostream>

void swap_pointer(double *a, double *b){

std::cout << "a value: " << *a << std::endl;
std::cout << "b value: " << *b << std::endl;

double *c;
*c= *a;
*a = *b;
*b = *c;

std::cout << "a value: " << *a << std::endl;
std::cout << "b value: " << *b << std::endl;
};

/* void swap_ref(double &a, double &b){

std::cout << "a value: " << &a << std::endl;
std::cout << "b value: " << &b << std::endl;

double &c = a;
double &d = b;
double &a = d;
double &b = c;

std::cout << "a value: " << &a << std::endl;
std::cout << "b value: " << &b << std::endl;
}; */

int pointerfun(int foo){
  /* int bar = foo;
  std::cout << "a memory location: " << &bar << std::endl;
  int *barPointer;
  barPointer = &bar;
  std::cout << "a pointy location: " << barPointer << std::endl;*/

  double numberoneAddress = 264.324;
  double numbertwoAddress = 23432.321;
  double *numberonePointer = &numberoneAddress;
  double *numbertwoPointer = &numbertwoAddress;
  swap_pointer(numberonePointer, numbertwoPointer);
  // swap_ref(&numberoneAddress, &numbertwoAddress);

  return 0;

}
