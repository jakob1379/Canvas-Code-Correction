#include "2_6.h"
#include <cmath>
#include <iostream>

double newton_Raphson(double initialGuess, double epsilon){
  double x_prev = initialGuess;
  double x_next = initialGuess -1;
  double e = epsilon;
  for (size_t i = 1; i < 100; i++) {
    std::cout << "Current x: " << x_prev << '\n';
    double x_next = x_prev - ( pow(e, x_prev) + pow(x_prev, 3) - 5) / (pow(e, x_prev) + 3*pow(x_prev, 2));

    if (x_prev == x_next){
      i = 100;
      break;
    }
    else {
      x_prev = x_next;
    };
  };
  std::cout << "Final x value:" << '\n';
  return x_prev;
};

// it prints the final x value 3 times, and I don't know how to stop it, and everything I've tried just breaks the code as it is atm, so there's that. Also, any while loop I've tried to include also breaks it, and actually sends it into an infinite loop. So that's why there's no while loop.
