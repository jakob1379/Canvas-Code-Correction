//
//  5_3.cpp
//  Handin1
//
//  Created by Christiane Annodine Duus-Holm on 26/04/2020.
//  Copyright © 2020 Christiane Annodine Duus-Holm. All rights reserved.
//

#include <stdio.h>
#include<iostream>
#include "5_3.h"

//Implementation using pointers
void swap_pointer(double *a, double *b){
    //Printing which function is being used
    std::cout << "Using the function using pointers we have \n";
    //Printing a and b
    //std::cout << "Before swap we have a = " << *a << " and b = " << *b << "\n";
    //Swapping a and b
    double temp; /*Pointer used to store during switch*/
    temp = *a; /*Assigning a to temporary variable*/
    *a = *b; /*Storing b in a*/
    *b = temp; /*Storing the temporary variable (value a) in b*/
    //Printing swapped i and j
    //std::cout << "After swap we have a = " << *a << " and b = " << *b << "\n";
}

//Implementation using references
void swap_ref(double &a, double &b){
    //Printing which function is being used
    std::cout << "Using the function using references we have \n";
    //Printing out a and b
    //std::cout << "Before swap we have a = " << a << " and b = " << b << "\n";
    //Swapping a and b
    double c;
    c = a;
    a = b;
    b = c;
    //Printing out a and b after swap
    //std::cout << "After swap we have a = " << a << "and b = " << b << "\n";
}
