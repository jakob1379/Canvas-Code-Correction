//
//  5_10.cpp
//  Handin1
//
//  Created by Christiane Annodine Duus-Holm on 26/04/2020.
//  Copyright © 2020 Christiane Annodine Duus-Holm. All rights reserved.
//

#include <stdio.h>
#include "5_10.h"

#include <iostream>
#include <cmath>
#include <cassert>

//Implementation

//Implementation of determinant function (static)
static double determinant(double** A, int n);
double determinant(double** A, int n){
    double det = 0;
    double** submat = new double* [n];
    for (int i=0; i<n; i++){
        submat[i]=new double [n];
    }
    if(n==1)
        return A[0][0];
    else if(n==2)
        return ((A[0][0]*A[1][1])-(A[1][0]*A[0][1]));
    else{
        for (int k=0; k<n; k++){
            int subi=0;
            for (int i=1; i<n; i++){
                int subj=0;
                for (int j=0; j<n; j++){
                    if (j==k)
                    continue;
                    submat[subi][subj]=A[i][j];
                    subj++;
                }
                subi++;
            }
            det = det + (pow(-1, k)*A[0][k]*determinant(submat, n-1));
        }
    }
    return det;
}

//Allocate matrix memory function
static double** AllocateMatrixMemory(int numRows, int numCols);

double** AllocateMatrixMemory(int numRows, int numCols) {
    double** matrix;
    matrix = new double* [numRows];
    for (int i=0; i<numRows; i++)
    {
        matrix[i] = new double [numCols];
    }
    return matrix;
}

//Deallocating matrix memory
static void FreeMatrixMemory(int numRows, double** matrix);

void FreeMatrixMemory(int numRows, double** matrix)
{
    for (int i=0; i<numRows; i++) {
        delete[] matrix[i];
    }
    delete[] matrix;
}

//Printing matrix
static void PrintMatrix(double** matrix, int rows, int cols);

void PrintMatrix(double** matrix, int rows, int cols){
    for (int i=0; i<rows; i++){
        for (int j=0; j<cols;j++){
            std::cout << " " << matrix[i][j];
            if(j==cols-1){
                std::cout << "\n";
            }
        }
    }
}

//Printing column vector
static void PrintColVec(double *ColVec, int rows);

void PrintColVec(double *ColVec, int rows){
    for (int i=0; i<rows; i++){
        std::cout << " " << ColVec[i] << "\n";
    }
}


//Implementation of actual function
void guassian_elimination(double **A, double *b, double *u, int n){
    //Firstly we calculate the determinant of A, making sure it is non-singular
    double detA=0;
    detA=determinant(A, n);
    assert(detA!=0);
    //std::cout << "Determinant of A is " << detA << "\n";
    //After asserting non-singularity of A, we solve the system
    
    //When using Gaussian elimination we have N-1 steps, so we loop over these
    for (int k=0; k<n-1; k++){
        
        //Finding row n with largest value of A^(k)_{nk} for each column k
        double Ainit = A[k][k];
        int maxrow = k;
        for (int i=k+1; i<n; i++){
            if(A[i][k]>Ainit){
                maxrow=i;
                Ainit=A[i][k];
            }
        }
        //Making the P-matrix (maxrow=n in the book p. 253)
        double** P = AllocateMatrixMemory(n, n);
        for (int i=0; i<n; i++){
            for (int j=0; j<n; j++){
                if (( (i==j) && (i!=k) && (j!=k) && (j!=maxrow))
                    || ((i==k) && (j==maxrow))
                    || ((i==maxrow) && (j==k))){
                    P[i][j]=1;
                }
                else {
                    P[i][j]=0;
                }
            }
        }
        
        //Multiplying P with A
        double** PA = AllocateMatrixMemory(n, n);
        for (int i=0; i<n; i++){
            for (int j=0; j<n; j++){
                PA[i][j]=0; /*Initializing*/
                for (int l=0; l<n; l++){
                    PA[i][j]+=P[i][l]*A[l][j];
                }
            }
        }
        
        //Multiplying P with b
        double Pb [n];
        for (int i=0; i<n;i++){
            Pb[i]=0; /*Initializing*/
            for (int j=0; j<n; j++){
                Pb[i]+=P[i][j]*b[j];
            }
        }
        
        //Making b=Pb and A=PA
        for (int i=0; i<n; i++){
            for (int j=0; j<n; j++){
                A[i][j]=PA[i][j];
            }
            b[i]=Pb[i];
        }
        
        //Next step using the M's (book p. 250)
        for (int i=k+1; i<n; i++){
            double M=0.0; /*Initializing M*/
            M=A[i][k]/A[k][k];
            
            //Next A-matrix (p. 250)
            for (int j=k+1; j<n; j++){
                A[i][j]=A[i][j]-M*A[k][j];
            }
            //Next b-vector (p. 250)
            b[i]=b[i]-M*b[k];
            A[i][k]=0;
        }
    }
    
    //Solve for u (formula (A.3) on p. 251)
    for (int k=n-1; k>-1; k--){ /*Starting from n-1 since using later u's in expression for u[k]*/
        
        //Making the sum in A.3
        double sum=0.0;
        for (int i=k+1; i<n; i++){
            sum+=A[k][i]*u[i];
        }
        //Finding u
        u[k]=1/(A[k][k])*(b[k]-sum);
    }
    //Printing u
    std::cout << "u = \n";
    PrintColVec(u, n);
}
