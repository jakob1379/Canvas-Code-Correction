//
//  5_4.cpp
//  Handin1
//
//  Created by Christiane Annodine Duus-Holm on 26/04/2020.
//  Copyright © 2020 Christiane Annodine Duus-Holm. All rights reserved.
//

#include <stdio.h>
#include "5_4.h"
#include <cassert>
#include <cmath>

//Implementation mean
double calc_mean(double a[], int length)
{
    assert(length > 0);
    double mean=0; /*Declaring the mean*/
    double sum=0; /*Declaring the sum*/
    for (int i=0; i<length; i++)
    {
        sum+=a[i]; /*Calculating the sum*/
    }
    mean = sum/length;
    return mean;
}

//Implementation sd
double calc_std(double a[], int length){
    assert(length>1);
    double mean=calc_mean(a, length);
    //calculating sum in sd
    double sumarray[length];
    for (int i=0; i<length; i++){
        sumarray[i]=pow((a[i]-mean),2);
    }
    double sdsum=0;
    for (int i=0; i<length; i++){
        sdsum+=sumarray[i];
    }
    double sd=0;
    sd=sqrt(sdsum/(length-1));
    return sd;
}
