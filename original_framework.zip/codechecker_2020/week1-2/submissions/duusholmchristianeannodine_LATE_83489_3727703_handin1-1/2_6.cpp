//
//  2_6.cpp
//  Handin1
//
//  Created by Christiane Annodine Duus-Holm on 25/04/2020.
//  Copyright © 2020 Christiane Annodine Duus-Holm. All rights reserved.
//

#include <stdio.h>
#include "2_6.h"

#include <iostream>
#include<cmath>

double newton_Raphson(double initialGuess, double epsilon)
{
    double x_next;
    double f_x, fp_x;
    bool not_converged = true;
    while(not_converged){ /*Checking it has not converged*/
        f_x=exp(initialGuess)+pow(initialGuess,3)-5; /*Defining f*/
        fp_x=exp(initialGuess)+3*pow(initialGuess,2); /*Defining derivative of f*/
        x_next=initialGuess-f_x/fp_x; /*Calculating next x*/
        not_converged=(fabs(initialGuess-x_next)>epsilon); /*Checking if converged*/
        initialGuess=x_next; /*Storing new value of x*/
    }
    return initialGuess;
}



