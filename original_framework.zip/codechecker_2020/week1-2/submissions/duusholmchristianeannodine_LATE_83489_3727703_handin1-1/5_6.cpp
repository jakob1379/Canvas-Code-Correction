//
//  5_6.cpp
//  Handin1
//
//  Created by Christiane Annodine Duus-Holm on 26/04/2020.
//  Copyright © 2020 Christiane Annodine Duus-Holm. All rights reserved.
//

#include <stdio.h>
#include<iostream>
#include <cassert>
#include "5_6.h"

// Implementation 1) - Matrix and matrix
void Multiply(double ** res, double **A, double **B, int ARows, int ACols, int BRows, int BCols)
{
    assert(ACols=BRows); /*Making sure the dimensions are correct*/

    //Initializing result matrix
    for(int i = 0; i < ARows; ++i)
    {
        for(int j = 0; j < BCols; ++j)
        {
            res[i][j] = 0;
        }
    }
    
    //Multiplying A and B and storing in res
    for(int i = 0; i < ARows; ++i)
    {
        for(int j = 0; j < BCols; ++j)
        {
            for(int k=0; k<ACols; ++k)
            {
                res[i][j] += A[i][k] * B[k][j];
            }
        }
    }
    
    //Printing res
    std::cout << "res=" << "\n";
    for (int i=0; i<ARows; i++){
        for (int j=0; j<BCols;j++){
            std::cout << " " << res[i][j];
            if(j==BCols-1){
                std::cout << "\n";
            }
        }
    }
}


//Implementation 2) - Vector and matrix
void Multiply(double *res, double *A, double **B, int ACols, int BRows, int BCols)
{
    assert(ACols=BRows); /*Making sure the dimensions are correct*/

    //Initializing result matrix
    for (int i=0; i<BCols; i++){
        res[i]=0;
    }
    
    //Multiplying A and B and storing in res
    for (int i=0; i < BCols; i++){
        for (int j=0; j<ACols; j++){
            res[i]+=A[j]*B[j][i];
        }
    }

    //Printing res
    std::cout << "res=" << "\n";
    for (int i=0; i<BCols; i++){
        std::cout << " " << res[i];
        if(i==BCols-1){
            std::cout << "\n";
        }
    }
}


//Implementation 3) - Matrix and vector
void Multiply(double *res, double **A, double *B, int ARows, int ACols, int BRows)
{
    assert(ACols=BRows); /*Making sure the dimensions are correct*/

    //Initializing result matrix
    for (int i=0; i<ARows; i++){
        res[i]=0;
    }
    
    //Multiplying A and B and storing in res
    for (int i=0; i < ARows; i++){
        for (int j=0; j<ACols; j++){
            res[i]+=A[i][j]*B[j];
        }
    }
    //Printing res
    std::cout << "res=" << "\n";
    for (int i=0; i<ARows; i++){
        std::cout << " " << res[i] << "\n";
    }
}


// Implementation 4) - Scalar and matrix
void Multiply(double **res, double scalar, double **B, int BRows, int BCols)
{
    //Initializing result matrix
    for(int i = 0; i < BRows; ++i)
    {
        for(int j = 0; j < BCols; ++j)
        {
            res[i][j] = 0;
        }
    }
    
    //Multiplying scalar and B and storing in res
    for(int i = 0; i < BRows; ++i)
    {
        for(int j = 0; j < BCols; ++j)
        {
            res[i][j]=scalar*B[i][j];
        }
    }

    //Printing res
    std::cout << "res=" << "\n";
    for (int i=0; i<BRows; i++){
        for (int j=0; j<BCols;j++){
            std::cout << " " << res[i][j];
            if(j==BCols-1){
                std::cout << "\n";
            }
        }
    }
}


//Implementation 5) - Matrix and scalar
void Multiply(double **res, double **B, double scalar, int BRows, int BCols)
{
    //Initializing result matrix
    for(int i = 0; i < BRows; ++i)
    {
        for(int j = 0; j < BCols; ++j)
        {
            res[i][j] = 0;
        }
    }
    
    //Multiplying scalar and B and storing in res
    for(int i = 0; i < BRows; ++i)
    {
        for(int j = 0; j < BCols; ++j)
        {
            res[i][j]=scalar*B[i][j];
        }
    }

    //Printing res
    std::cout << "res=" << "\n";
    for (int i=0; i<BRows; i++){
        for (int j=0; j<BCols;j++){
            std::cout << " " << res[i][j];
            if(j==BCols-1){
                std::cout << "\n";
            }
        }
    }
}

