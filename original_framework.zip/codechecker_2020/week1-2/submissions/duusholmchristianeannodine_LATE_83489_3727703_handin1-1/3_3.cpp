//
//  3_3.cpp
//  Handin1
//
//  Created by Christiane Annodine Duus-Holm on 26/04/2020.
//  Copyright © 2020 Christiane Annodine Duus-Holm. All rights reserved.
//

#include <stdio.h>
#include "3_3.h"
#include <cassert>
#include <iostream>
#include <fstream>

void implicit_Euler(int n)
{
    assert(n>1);  /*Ensure more than 1 grid point*/
    double h=1/((double) n); /*Calculate stepsize*/
    
    // Prepare output file for writing
    std::ofstream write_output("xy.dat");
    assert(write_output.is_open());
    
    //Euler method to solve initial value problem for dy/dx, y0=1
    double x[n];
    double y[n];
    x[0]=0.0; /*x0=0*h*/
    y[0]=1.0; /*y0=1*/
    for (int i=1; i<=n; i++){
        y[i]=y[i-1]/(h+1.0); /*Using rewrite of expression in 3.3)*/
        x[i]=((double) (i))*h;
    }
    for (int i=0; i<=n; i++){
        write_output << x[i] << "," << y[i] << "\n";
    }
    write_output.close();
}

