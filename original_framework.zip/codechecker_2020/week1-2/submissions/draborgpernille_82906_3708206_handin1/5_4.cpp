#include <iostream>
#include <cmath> 
#include "5_4.h"


double calc_mean(double a[] , int length)
{
    double sum = 0.0;                                   // initialize sum with 0
    
    for (int i=0; i<length; i++)
    {
        sum += a[i];                                    // sum all of the entries of a
    }
    
    return sum/length;                                  // we need the mean ie. sum divided by number of entries of a
}


double calc_std(double a[] , int length)
{
    double mean;
    double std = 0.0;                                    // initialize the standard deviance
    
    mean = calc_mean(a,length);                          // calculate the mean of a
    
    if (length-1 > 0)                                    // we can't divide by 0
    {
        for (int j=0; j<length; j++)
        {
            std += pow(a[j]-mean,2);
        }
        return sqrt(std/(length-1));
    }
    else
    {
        return 0;                                        // we can't calculate the standard deviance, if we only have one entry
    }
    
}

