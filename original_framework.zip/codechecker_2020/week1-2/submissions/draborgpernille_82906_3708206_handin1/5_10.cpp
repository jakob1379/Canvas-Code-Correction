#include <iostream>
#include <cmath>
#include "5_10.h"


// swap rows in A
void swap_rows_A (int r1, int r2, double **A, int n)
{
	double temp;
	
	for(int j=0; j<n; j++)
	{
		temp = A[r1][j];
		A[r1][j] = A[r2][j];
		A[r2][j] = temp;
	}
}

// swap rows in b
void swap_rows_b (int r1, int r2, double *b, int n)
{
	double temp;
	
	temp = b[r1];
	b[r1] = b[r2];
	b[r2] = temp;
	
}

// Pivot until we have a pivot element in the diagonal
void pivot (double **A, double *b, int n, int j)
{
	double epsilon = 0.0001;
	
	if(fabs(A[j][j]) <= epsilon)
	{
		int max_position = j;
		for(int i = j+1; i<n; i++)
		{
			if(fabs(A[i][j])>fabs(A[max_position][j]))
			{
				max_position = i;
			}
		}
		swap_rows_A(max_position, j, A, n);
		swap_rows_b(max_position, j, b, n);
		
	}
	
}


void guassian_elimination (double **A, double *b, double *u, int n) 
{ 
	
	for(int j=0; j<n; j++)							// runs over the columns
	{
		pivot(A, b, n, j);							// after every iteration we must have a pivot
		
		double f=1/A[j][j];					        // Makes a variable that makes the diagonal element to 1  l
		for(int i=j; i<n; i++)
		{
			A[j][i] = f * A[j][i];				    // Multiplies all numbers in the row by f variable
		}
		b[j] = f * b[j];						    // Multiplies the f variable in the result vector b
		 
		for(int i=j+1; i<n; i++)
		{
			double sub_f = A[i][j];			        // How many times we need to subtract the row to get a 0 beneath it
			for(int k=0; k<n; k++)
			{
				A[i][k] -= sub_f * A[j][k];	        // Subtract in the matrix
			}
			b[i] -= sub_f * b[j];			     	// Subtract in the result
			
		}
	}
	
	
	// backward substitution
	u[n-1]=b[n-1]/A[n-1][n-1];
	
	for(int i=n-2; i>=0; i--)
	{
		double sum = b[i];
		for(int j=i+1; j<n; j++)
		{
			sum -= A[i][j] * u[j];
		}
		u[i]=sum/A[i][i];
	}
	
}

