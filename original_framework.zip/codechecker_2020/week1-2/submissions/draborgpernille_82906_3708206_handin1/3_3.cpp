#include <iostream>
#include <cassert>
#include <string>
#include <cmath> 
#include <fstream>
#include "3_3.h"

void implicit_Euler(int n) {
	
	assert(n > 1);										// ensures that the number of grid points is greater than 1 (we must not divide by 0)
	
	double x[n-1];										// making an x vector
    double y[n-1];                                      // making an y vector
	double tmp = double(n);								// to calculate the stepsize h, which is a double, we must convert n to a double
	double h = 1/(tmp - 1);								// calculates the stepsize


    x[0]=0;
	y[0]=1;												// initial values given
	
	std::ofstream write_output("xy.dat");				// specifies that we need to write output to the file xy.dat
	assert(write_output.is_open());						// makes sure that we can access this file
	
	for(int i=1; i<n-1; i++)
	{
		y[i] =  y[i-1] / (1+h);                         // yi is the solution at xi =ih
		x[i] = i * h;
		write_output << x[i] << "," << y[i] <<"\n";		// writes the entries of the arrays x and y to xy.dat
	}
	write_output.close();								// closes the file xy.dat
}








