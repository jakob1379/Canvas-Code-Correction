//
//  2_6.cpp
//  2_6
//
//  Created by Pernille Draborg on 21/04/2020.
//  Copyright © 2020 Pernille Draborg. All rights reserved.
//

#include <iostream>
#include <cassert>
#include <cmath>
#include "2_6.h"

double f (double x){
    return exp(x) + pow(x,3) - 5; // First we define the function
}

double fm (double x){
    return exp(x) + 3 * pow(x,2); // Then we define the differentiated function
}

// Now we define the Newton Raphson algorithm
double newton_Raphson(double initialGuess , double epsilon)
{
    double x_i; // x_i
    double x_imo; // x_(i-1) (imo = i minus one)
    
    x_imo = initialGuess;
    x_i = x_imo- f(x_imo) / fm(x_imo);                            // This is the first step of the algorithm
    
    if(fabs(x_imo-x_i) < epsilon )                                // This checks whether the iterations have converged
    {
        return x_i;                                                // If the condition is already met at the beginning, the iterations stops here
    }
    else                                                        // If the condition is not met at the beginning, we iterate
    {
        while(fabs(x_imo-x_i) >= epsilon)                        // and iterate until the condition is satisfied
        {
            x_imo = x_i;
            x_i = x_imo - f(x_imo) / fm(x_imo);
        }
    return x_i;
    }
}
