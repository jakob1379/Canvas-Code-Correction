#include <iostream>
#include <cassert>
#include <fstream>
#include "5_3.h"

void swap_pointer(double *a , double *b)    //using pointers
{
    double lim;
    lim = *a;
    *a = *b;
    *b = lim;
}

void swap_ref(double &a, double &b)         //using references
{
    double lim;
    lim = a;
    a = b;
    b = lim;
}
