#include <iostream>
#include <cmath>
#include "5_9.h"


void solve3by3( double **A, double *b , double *u) 
{
    // The solution to Au=b is u=A^(-1)b. Hence we must first find the inverse of A. The inverse of a 3x3 matrix is defined here https://mathworld.wolfram.com/MatrixInverse.html and  here http://www.mathcentre.ac.uk/resources/uploaded/sigma-matrices11-2009-1.pdf
    // We thus need a function to calculate determinants and a function to put the inverse matrix together
    
    
    // we first define the function to calculate the determinant of the 3x3 matrix. The formula can be found here: https://www.mathsisfun.com/algebra/matrix-determinant.html
       
        double determinant=0;
        double inverse[3][3];
        
    
        // Finding the determinant
        for(int i=0; i<3; i++){
            determinant += A[0][i] * (A[1][(i+1)%3] * A[2][(i+2)%3] - A[1][(i+2)%3] * A[2][(i+1)%3]);
        }
        
    
        // Finding the inverse
        for(int i=0; i<3; i++){
            for(int j=0; j<3; j++){
                inverse[i][j] = (A[(j+1)%3][(i+1)%3] * A[(j+2)%3][(i+2)%3] - A[(j+1)%3][(i+2)%3] * A[(j+2)%3][(i+1)%3])/ determinant;
            }
        }
        
        u[0] = inverse[0][0] * b[0] + inverse[0][1] * b[1] + inverse[0][2] * b[2];
        u[1] = inverse[1][0] * b[0] + inverse[1][1] * b[1] + inverse[1][2] * b[2];
        u[2] = inverse[2][0] * b[0] + inverse[2][1] * b[1] + inverse[2][2] * b[2];
        
        
    }

