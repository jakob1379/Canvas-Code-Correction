#include <iostream> 
#include <cmath>
#include <cassert>
#include "5_6.h"


// 5.5, the function below multiplies to matrices
void Multiply(double **res , double **A, double **B, int ARows, int ACols , int BRows, int BCols)
{
    // Need to check if the matrices are of suitable sizes
    // if A= nxm and B= mxh then the two matrices can be multiplied. Ie. We need the columns of A to equal the rows of B.
    assert(ACols = BRows);
    
    // if the above statement is true, we can multiply the matrices
    for(int i=0; i<ARows; i++)
    {
        for(int j=0; j<BCols; j++)
        {
            res[i][j] = 0;
            
            for(int k=0; k<ACols; k++)
            {
                res[i][j] += A[i][k] * B[k][j];
            }
        }
    }
}



// Vector times a matrix
void Multiply(double *res , double *A, double **B, int ACols , int BRows, int BCols)

{
    assert(ACols=BRows);
    
    for(int i=0; i<BCols; i++)
    {
        // when A is a vector (1xn) the output will be a vector as well
        res[i] = 0;
        
        for(int j=0; j<ACols; j++)
        {
            res[i] += A[j] * B[j][i];
        }
    }
}


// Matrix times a vector
void Multiply(double  *res , double   **A, double  *B, int ARows, int ACols , int BRows)
{
    assert(ACols=BRows);
    
    for (int i=0; i<ARows; i++)
    {
        // When B is a vector (nx1) the output will be a vector as well
        res[i] = 0;
        
        for (int j=0; j< ACols; j++)
        {
            res[i] += A[i][j] * B[j];
        }
    }
}


// Scalar times a matrix
void Multiply(double **res , double scalar , double **B, int BRows, int BCols)
{
    for(int i=0; i<BRows; i++)
    {
        for(int j=0; j<BCols; j++)
        {
           // only need to set res = 0 when using +=
           res[i][j] = scalar * B[i][j];
        }
    }
}

//Matrix times a scalar
void Multiply(double  **res , double  **B, double scalar , int BRows, int BCols)
{
    for(int i=0; i<BRows; i++)
    {
        for(int j=0; j<BCols; j++)
        {
           // only need to set res = 0 when using +=
           res[i][j] = B[i][j] * scalar;
        }
    }
}

