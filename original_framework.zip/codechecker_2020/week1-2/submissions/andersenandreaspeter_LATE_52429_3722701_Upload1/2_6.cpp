#include "2_6.h"
#include <iostream>
#include <cmath>

double func(double x) {
    return exp(x)+x*x*x-5;
}
double d_func(double x) {
    return exp(x)+3*x*x;
}
double newton_Raphson(double x, double epsilon, int maxIterations) {
    int iterations = 0;
    double h = func(x)/d_func(x);
        while ((fabs(h) >= epsilon) &&
               (iterations < maxIterations))
        {
            h = func(x)/d_func(x);
            x = x - h;
        }
    return x;
}
/*
int main(int argc, char* argv[])
{
    double x = 0; 
    double epsilon = 10e-6; 
    int maxIterations = 100;
    double newton_value = newton_Raphson(x, epsilon, maxIterations);
    std::cout << newton_value << "\n";
    return 0;
}
*/