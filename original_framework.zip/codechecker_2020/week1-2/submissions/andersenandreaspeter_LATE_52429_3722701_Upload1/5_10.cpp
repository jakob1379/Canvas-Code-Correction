#include <cmath>
#include "5_10.h"
#include <algorithm>
#include <iostream>
void guassian_elimination(double **A,double *b,double *u, int n);
double** AllocateSquareMatrix(int n);
void freeMatrixMemory(int n,double **A);
void pivot(double **A, double *b,double*u, int start_index, int n);
/*
int main(int argc, char* argv[])
{
	int test_n = 3;
	double * b;
	b = new double [test_n];
	double* u;
	u = new double [test_n];
    b[0]=6;
    b[1]=1;
    b[2]=8;
	
	double** matrix = AllocateSquareMatrix(test_n);
	for (int i = 0;i<test_n;i++)
	{
		for (int j=0;j<test_n;j++)
		{
			matrix[i][j] = 1.0;
		}
	}
	matrix[0][0] = 1.0;
	matrix[0][1] = 1.0;
    matrix[0][2] = 1.0;
    matrix[1][0] = 2.0;
    matrix[1][1] = 1.0;
    matrix[1][2] = -1.0;
    matrix[2][0] = 1.0;
    matrix[2][1] = 2.0;
    matrix[2][2] = 1.0;
	std::cout << "Matrix                      \n";
	//pivot(matrix,b,u,2,4);
	guassian_elimination(matrix,b,u,test_n);
	for (int i = 0;i<test_n;i++)
	{
		std::cout << " \n";

		for (int j=0;j<test_n;j++)
		{
			std::cout << matrix[i][j] << "\t";
		}
	}
	for (int i = 0; i<test_n;i++)
	{
		std::cout << "\n";
		std::cout << u[i] << "\t" << b[i];
	}

	freeMatrixMemory(test_n,matrix);
}
*/
void guassian_elimination(double **A,double *b, double *u, int n)
{
	if (n == 1) u[0] = A[0][0]/b[0];
	double temp_m = 0;
	double temp_sum;
	pivot(A,b,u,-1,n);
	for(int i = 0;i<n-1;i++)
	{
		pivot(A,b,u,i,n);
		for (int j = i+1;j<n;j++)
		{
			temp_m = A[j][i]/A[i][i];
			for(int k = i;k<n;k++)
			{
				A[j][k] -=temp_m*A[i][k];
				//std::cout << "\n     K:    " << k << "\n"; 
			}
			b[j] -= temp_m*b[i];
		}
		if((i < n-2) && A[i+1][i+1]==0) 
		{
			//std::cout << "CHECK";
			for (int m = i+2;m<n;m++)
			{
			//std::cout << m;
				if (A[m][i+1] != 0)
				{
				//std::cout << "NEJ";
					std::swap(A[i+1],A[m]);
					std::swap(b[i+1],b[m]);
					break;
				}
			}
		}
 
		

	}
	u[n-1] = b[n-1]/A[n-1][n-1];
	
	for (int i = n-2; i > -1; i--)
	{
		temp_sum = 0;	
		
		for (int j = i+1;j<n;j++)
		{
			temp_sum += A[i][j]*u[j];
		}
		u[i] = (1/A[i][i])*(b[i]-temp_sum);
	}
}
double** AllocateSquareMatrix(int n)
{
	double** matrix;
	matrix = new double* [n];
	for (int i = 0;i<n;i++)
	{
		for (int i = 0;i<n;i++)
		{
			matrix[i] = new double [n];
		}
	}
	return matrix;
}
void freeMatrixMemory(int n, double **A)
{
	for (int i = 0;i<n;i++)
	{
		delete [] A[i];
	}
	delete [] A;
}
void pivot(double **A,double *b, double *u, int start_index,int n)
{
	double current_largest = 0;
	int index_of_biggest = start_index+1;
	double temp;
	for (int i=start_index+1;i<n;i++)
	{
		
		if(fabs(A[i][start_index]) > current_largest)
		{
			current_largest = fabs(A[i][start_index]);
			index_of_biggest = i;
		}
	}
	std::swap(u[start_index+1],u[index_of_biggest]);
	std::swap(b[start_index+1],b[index_of_biggest]);
	std::swap(A[start_index+1],A[index_of_biggest]);
}


