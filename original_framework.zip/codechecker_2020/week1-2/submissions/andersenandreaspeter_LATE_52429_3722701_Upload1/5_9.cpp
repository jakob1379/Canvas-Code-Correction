#include <iostream>
#include <cmath>
#include "5_9.h"
void solve3by3(double **A,double *b,double *u);
double find_determinant(double **A);
double find_determinant(double A[3][3]);
double copy_vector_find_det(double A[3][3], double *b,int column_no);

/*
int main(int argc, char* argv[])
{
	double **matrix;
	matrix = new double* [3];
	for (int i=0;i<3;i++)
	{
		matrix[i] = new double [3];
	}
	for (int i=0;i<3;i++)
	{
		for (int j=0;j<3;j++)
		{
		matrix[i][j] = 1.0;
		}
	}
	matrix[2][1] = 5.0;
	matrix[0][1] = 10.0;
	matrix[1][1] = 2.5;
	matrix[0][2] = 7.0;
	
	matrix[0][2] = 0.0;
	matrix[2][0] = 0.0;
	matrix[1][1] = 0.0;
	
	double *x,*u;
	x = new double [3];
	u = new double [3];
	x[0] = 5.0;
	x[1] = 5.0;
	x[2] = 5.0;
	
	solve3by3(matrix,x,u);
	std::cout << "\n";
	for (int i = 0;i < 3;i++)
	{
		std::cout << u[i] << "\n";
	}	
}
*/


void solve3by3(double **A,double *b, double *u)
{
	
	int matrix_dim = 3;
	double detA = find_determinant(A);
	double temp_matrix[3][3];
	for(int i = 0;i<matrix_dim;i++)
	{
		for(int j=0;j<matrix_dim;j++)
		{
			temp_matrix[i][j] = A[i][j];
		}
	}
	for(int i = 0; i < matrix_dim;i++)
	{
		u[i] = copy_vector_find_det(temp_matrix,b,i)/detA;
	}
		
}
double find_determinant(double **A)
{
	double determinant = A[0][0]*(A[1][1]*A[2][2]-A[1][2]*A[2][1])
	                   - A[0][1]*(A[1][0]*A[2][2]-A[1][2]*A[2][0])
	                   + A[0][2]*(A[1][0]*A[2][1]-A[1][1]*A[2][0]);
	std::cout << "Det:  " << determinant << "\n";
	return determinant;
}

double find_determinant(double A[3][3])
{
	double determinant = A[0][0]*(A[1][1]*A[2][2]-A[1][2]*A[2][1])
					   - A[0][1]*(A[1][0]*A[2][2]-A[1][2]*A[2][0])
					   + A[0][2]*(A[1][0]*A[2][1]-A[1][1]*A[2][0]);
	//std::cout << determinant;
	return determinant;
}

double copy_vector_find_det(double A[3][3], double *b,int column_no)
{
	double temp[3];
	int matrix_dim = 3;
	for(int i = 0;i<matrix_dim;i++)
	{
		temp[i] = A[i][column_no];
		A[i][column_no] = b[i];
	}
	double determinant = find_determinant(A);
	std::cout << determinant;
	for(int i = 0;i<matrix_dim;i++)
	{
		A[i][column_no] = temp[i];
	}
	for (int i = 0;i<3;i++)
	{
		std::cout << "\n";
		for (int j = 0;j<3;j++)
		{
			//std::cout << A[i][j] << "\t";
		}
	}
	return determinant;
}

