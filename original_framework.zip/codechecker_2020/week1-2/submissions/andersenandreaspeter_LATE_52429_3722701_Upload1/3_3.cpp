#include <iostream>
#include <fstream>
#include <cmath>
#include <cassert>
#include <cstdlib>

void implicit_Euler(int n)
{
	double h = 1.0/n;
	double y=1.0;
	double x;
	std::ofstream write_output("xy.dat");
	assert(write_output.is_open());
	write_output << 0 << "," << 1 << "\n";
	for (int i=1;i<n;i++)
	{
		y=y/(1+h);
		x=i*h;
		write_output << x << "," << y << "\n";
	}
	write_output.close();
}

/*
int main(int argc, char* argv[])
{
		 int n = atoi(argv[1]);
		 assert(n > 1); 
		implicit_Euler(n);
		return 0;
}
*/