#ifndef H_5_10_H
#define H_5_10_H

void solve3by3(double **A, double *b, double *u);

#endif
