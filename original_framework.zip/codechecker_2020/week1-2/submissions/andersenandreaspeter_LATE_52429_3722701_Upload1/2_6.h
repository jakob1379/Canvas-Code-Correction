#ifndef H_2_6_H
#define H_2_6_H
#include "2_6.h"
#include <iostream>
#include <cmath>



double newton_Raphson(double initialGuess, double epsilon);

#endif
