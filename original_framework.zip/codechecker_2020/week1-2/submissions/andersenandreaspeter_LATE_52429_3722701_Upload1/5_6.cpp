#include "5_6.h"
#include <iostream>
#include <cmath>
#include <cstdlib>
#include <cassert>
#include <fstream>

//A Matrix, B Matrix    
void Multiply(double **res, double **A, double **B, int ARows, int ACols, int BRows, int BCols)
{
    double s=0;
    for(int i=0;i<ARows;i++)
    {
        for(int j=0;j<BCols; j++)
        {
            for(int k=0;k<ACols; k++)
            {
                s+= A[i][k]*B[k][j];
            }
            res[i][j]=s;
            s=0;
        }
    }
}

//A Vector, B Matrix
void Multiply(double *res, double *A, double **B, int ACols, int BRows, int BCols)
{
	double s=0;
	for (int i=0; i<BCols;i++)
	{
		for (int j=0; j< ACols; j++)
		{
			s += A[j]*B[j][i];
		}
		res[i] = s;
		s=0;
	}	
}

//A Matrix, B Vector
void Multiply(double *res, double **A, double *B, int ARows, int ACols, int BRows, int BCols)
{
	double s=0;
	for (int i=0; i<ARows;i++)
	{
		for (int j=0; j< BRows; j++)
		{
			s += A[i][j]*B[j];
		}
		res[i] = s;
		s=0;
	}
}

//Scalar and Matrix
void Multiply(double **res,double scalar, double **B, int BRows, int BCols)
{
	for (int i=0;i<BRows;i++)
	{
		for (int j=0;j<BCols;j++)
		{
			res[i][j] = scalar * B[i][j];
		}
	}
}

//Matrix and Scalar
void Multiply(double **res,double **B, double scalar, int BRows, int BCols)
{
	for (int i=0; i< BRows ;i++)
	{
		for (int j=0; j<BCols ; j++)
		{
			res[i][j] = B[i][j] * scalar;
		}
	}	
}
