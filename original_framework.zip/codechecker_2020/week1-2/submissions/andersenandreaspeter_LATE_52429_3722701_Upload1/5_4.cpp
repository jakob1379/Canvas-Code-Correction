#include "5_4.h"
#include <iostream>
#include <cmath>
#include <cstdlib>
#include <cassert>
#include <fstream>


double calc_mean(double a[], int length)
{
	double m;
	for (int i=0;i<length;i++)
	{
	m += a[i];
	}
	m=m/length;
    return m;
}

double calc_std(double a[], int length)
{
    double sd = 0.0;
    double m = calc_mean(a,length);
    if(length>1)
    {
        for(int i=0;i<length;i++)
        {
            sd+= pow(a[i]-m,2);
        }
        sd = sqrt(sd/(length-1));
    }
    else
    {
        sd=0;
    }
    return sd;
}
/*
int main(int argc, char* argv[]){
		int length=5;
		double m;
		double sd;
		double a[5] = {10,28,31,49,50};
		m=calc_mean(a,length);
		sd=calc_std(a,length);
		std::cout << "Mean is " << m << " std is " << sd << "\n";
		return 0;
}	
*/