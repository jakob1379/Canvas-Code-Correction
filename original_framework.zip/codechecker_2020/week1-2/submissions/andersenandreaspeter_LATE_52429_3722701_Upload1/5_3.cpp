/* 5.3*/
#include "5_3.h"
#include <cmath>
#include <iostream>
#include <cstdlib>
#include <cassert>
#include <fstream>

void swap_pointer(double *a, double *b)
{
	std::cout << *a << "," << *b << "\n";
	double mid = *a;
	*a = *b;
	*b = mid; 
	std::cout << *a << "," << *b << "\n";
}

void swap_ref(double &a, double &b)
{
	std::cout << a << "," << b << "\n";
	double mid=a;
	a = b;
	b = mid; 
	std::cout << a << "," << b << "\n";
}
/*
int main(int argc, char* argv[]){
		double a=1;
		double b=2;
		double* p_a=new double;
		double* p_b=new double;
		*p_a = a;
		*p_b = b;
		swap_pointer(p_a, p_b);
		swap_ref(a,b);
		return 0;
		delete p_a;
		delete p_b;
}
*/

/*void swap_ref(double &a, double &b);*/