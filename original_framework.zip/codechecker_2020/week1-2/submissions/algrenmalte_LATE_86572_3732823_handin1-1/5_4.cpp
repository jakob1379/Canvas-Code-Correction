#include "5_4.h"
#include <iostream> // input and output stream
#include <math.h>


double calc_mean(double a[], int length){
  double mean = 0.0;
  for (int i = 0; i < length; i++) {
    mean += a[i];
  }
  mean = mean/length;

  return mean;
};
double calc_std(double a[], int length){
  double mean = calc_mean(a, length);

  double std = 0;
  for (int i = 0; i < length; i++) {
    std += (a[i]-mean)*(a[i]-mean);
  }
  std = sqrt(std/(length));
  return std;
};
