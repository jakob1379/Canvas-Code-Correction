#include "3_3.h"
#include <iostream> // input and output stream
#include <math.h>
#include <assert.h>
#include <fstream>
#include <string>
using namespace std;


void implicit_Euler(int n){
  assert (n > 1);
  double h = (double) 1/ (double)n;
  double y = 1.0;
  double x = 0.0;
  ofstream myfile;
  myfile.open("xy.dat");
  for (int i = 0; i < n; i++) {
    myfile << x << ", " << y << "\n";
    y = y - h*y;
    x = h * (double)i;
  }
  myfile.close();
  return;
}
