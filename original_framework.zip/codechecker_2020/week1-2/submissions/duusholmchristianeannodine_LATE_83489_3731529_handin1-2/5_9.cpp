//
//  5_9.cpp
//  Handin1
//
//  Created by Christiane Annodine Duus-Holm on 26/04/2020.
//  Copyright © 2020 Christiane Annodine Duus-Holm. All rights reserved.
//

#include <stdio.h>
#include "5_9.h"

#include <iostream>
#include <cassert>
#include <cmath>

//Implementation
//Allocate matrix memory function
static double** AllocateMatrixMemory(int numRows, int numCols);

double** AllocateMatrixMemory(int numRows, int numCols) {
    double** matrix;
    matrix = new double* [numRows];
    for (int i=0; i<numRows; i++)
    {
        matrix[i] = new double [numCols];
    }
    return matrix;
}

//Deallocating matrix memory
static void FreeMatrixMemory(int numRows, double** matrix);
void FreeMatrixMemory(int numRows, double** matrix)
{
    for (int i=0; i<numRows; i++) {
        delete[] matrix[i];
    }
    delete[] matrix;
}

//Printing matrix
static void PrintMatrix(double** matrix, int rows, int cols);

void PrintMatrix(double** matrix, int rows, int cols){
    for (int i=0; i<rows; i++){
        for (int j=0; j<cols;j++){
            std::cout << " " << matrix[i][j];
            if(j==cols-1){
                std::cout << "\n";
            }
        }
    }
}

//Printing column vector
static void PrintColVec(double *ColVec, int rows);

void PrintColVec(double *ColVec, int rows){
    for (int i=0; i<rows; i++){
        std::cout << " " << ColVec[i] << "\n";
    }
}

//Implementation of determinant function (static)
static double determinant(double** A, int n);
double determinant(double** A, int n){
    double det = 0;
    double** submat = new double* [n];
    for (int i=0; i<n; i++){
        submat[i]=new double [n];
    }
    if(n==1)
        return A[0][0];
    else if(n==2)
        return ((A[0][0]*A[1][1])-(A[1][0]*A[0][1]));
    else{
        for (int k=0; k<n; k++){
            int subi=0;
            for (int i=1; i<n; i++){
                int subj=0;
                for (int j=0; j<n; j++){
                    if (j==k)
                    continue;
                    submat[subi][subj]=A[i][j];
                    subj++;
                }
                subi++;
            }
            det = det + (pow(-1, k)*A[0][k]*determinant(submat, n-1));
        }
    }
    FreeMatrixMemory(n, submat);
    return det;
}


//Implementation of actual solving function
void solve3by3(double **A, double *b, double *u){
    //Firstly we calculate the determinant of A, making sure it is non-singular
    double detA=0;
    detA=determinant(A, 3);
    assert(detA!=0);
    std::cout << "Determinant of A is " << detA << "\n";
    //After asserting non-singularity of A, we solve the system
    
    //Transposing A
    //Allocating memory for transposed matrix
    double** ATrans = AllocateMatrixMemory(3, 3);
    //Assigning values
    for (int i=0; i<3; i++){
        for (int j=0; j<3; j++){
            ATrans[j][i]=A[i][j];
        }
    }
    //Printing transpose of A (sanity check that transposed correctly)
    //std::cout << "A^T=" << "\n";
    //PrintMatrix(ATrans, n, n);
    
    //Declaring each submatrix
    double** A00=AllocateMatrixMemory(3-1, 3-1);
    double** A01=AllocateMatrixMemory(3-1, 3-1);
    double** A02=AllocateMatrixMemory(3-1, 3-1);
    double** A10=AllocateMatrixMemory(3-1, 3-1);
    double** A11=AllocateMatrixMemory(3-1, 3-1);
    double** A12=AllocateMatrixMemory(3-1, 3-1);
    double** A20=AllocateMatrixMemory(3-1, 3-1);
    double** A21=AllocateMatrixMemory(3-1, 3-1);
    double** A22=AllocateMatrixMemory(3-1, 3-1);
    
    //Assigning values to the sub-matrices
    A00[0][0]=ATrans[1][1]; A00[0][1]=ATrans[1][2]; A00[1][0]=ATrans[2][1]; A00[1][1]=ATrans[2][2];
    A01[0][0]=ATrans[1][0]; A01[0][1]=ATrans[1][2]; A01[1][0]=ATrans[2][0]; A01[1][1]=ATrans[2][2];
    A02[0][0]=ATrans[1][0]; A02[0][1]=ATrans[1][1]; A02[1][0]=ATrans[2][0]; A02[1][1]=ATrans[2][1];
    A10[0][0]=ATrans[0][1]; A10[0][1]=ATrans[0][2]; A10[1][0]=ATrans[2][1]; A10[1][1]=ATrans[2][2];
    A11[0][0]=ATrans[0][0]; A11[0][1]=ATrans[0][2]; A11[1][0]=ATrans[2][0]; A11[1][1]=ATrans[2][2];
    A12[0][0]=ATrans[0][0]; A12[0][1]=ATrans[0][1]; A12[1][0]=ATrans[2][0]; A12[1][1]=ATrans[2][1];
    A20[0][0]=ATrans[0][1]; A20[0][1]=ATrans[0][2]; A20[1][0]=ATrans[1][1]; A20[1][1]=ATrans[1][2];
    A21[0][0]=ATrans[0][0]; A21[0][1]=ATrans[0][2]; A21[1][0]=ATrans[1][0]; A21[1][1]=ATrans[1][2];
    A22[0][0]=ATrans[0][0]; A22[0][1]=ATrans[0][1]; A22[1][0]=ATrans[1][0]; A22[1][1]=ATrans[1][1];
    //Printing for sanity check
    //std::cout << "A22= \n";
    //PrintMatrix(A22, n-1, n-1);
    
    //Declaring new matrix
    double** Acof=AllocateMatrixMemory(3, 3);
    
    //Assigning values, letting entires correspond to determinant of submatrices
    Acof[0][0]=pow(-1, 0+0)*determinant(A00, 3-1);
    Acof[0][1]=pow(-1, 0+1)*determinant(A01, 3-1);
    Acof[0][2]=pow(-1, 0+2)*determinant(A02, 3-1);
    Acof[1][0]=pow(-1, 1+0)*determinant(A10, 3-1);
    Acof[1][1]=pow(-1, 1+1)*determinant(A11, 3-1);
    Acof[1][2]=pow(-1, 1+2)*determinant(A12, 3-1);
    Acof[2][0]=pow(-1, 2+0)*determinant(A20, 3-1);
    Acof[2][1]=pow(-1, 2+1)*determinant(A21, 3-1);
    Acof[2][2]=pow(-1, 2+2)*determinant(A22, 3-1);
    
    //Printing Acof for sanity
    //std::cout << "Acof = ";
    //PrintMatrix(Acof, n, n);
    
    //Declaring inverse of A
    double** Ainv = AllocateMatrixMemory(3, 3);
    //Assiging values to inverse
    for (int i=0; i<3; i++){
        for (int j=0; j<3; j++){
            Ainv[i][j]=1/(determinant(A, 3))*Acof[i][j];
       }
    }
    //Printing Ainv for sanity
    //std::cout << "Ainv = \n";
    //PrintMatrix(Ainv, n, n);
    
    //Initializing u
    for (int i=0; i<3; i++){
        u[i]=0;
    }
    
    //Assigning value to u by multiplying Ainv with b
    for (int i=0; i < 3; i++){
        for (int j=0; j<3; j++){
            u[i]+=Ainv[i][j]*b[j];
        }
    }
    
    //Printing u
    std::cout << "u = \n";
    PrintColVec(u, 3);
    
    //Deallocating memory for Atrans, Ainv, Acof and the submatrices
    FreeMatrixMemory(3, ATrans);
    FreeMatrixMemory(3, Ainv);
    FreeMatrixMemory(3, Acof);
    FreeMatrixMemory(2, A00);
    FreeMatrixMemory(2, A01);
    FreeMatrixMemory(2, A02);
    FreeMatrixMemory(2, A10);
    FreeMatrixMemory(2, A11);
    FreeMatrixMemory(2, A12);
    FreeMatrixMemory(2, A20);
    FreeMatrixMemory(2, A21);
    FreeMatrixMemory(2, A22);
}
