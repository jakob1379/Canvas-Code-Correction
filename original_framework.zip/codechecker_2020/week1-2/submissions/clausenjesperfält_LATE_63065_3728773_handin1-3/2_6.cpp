#include "2_6.h"
#include <math.h>
#include <cmath>

#define fNorm(x) (std::exp(x) + std::pow(x,3) - 5.0)
#define fDev(x) (std::exp(x) + (3*std::pow(x,2)))

double newton_Raphson(double initialGuess, double epsilon) {
    double x_prev, x_next;
    x_next = initialGuess;
    do
    {
        x_prev = x_next;
        x_next = x_prev - (fNorm(x_prev)/fDev(x_prev));
    } while (std::abs (x_next - x_prev) > epsilon);
    return x_next;
}