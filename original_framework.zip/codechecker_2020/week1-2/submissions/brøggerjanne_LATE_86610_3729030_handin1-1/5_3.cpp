#include <iostream>
#include <cmath>
#include "5_3.h"

void swap_pointer(double *a, double *b)
{
	std::cout << "Før kode er eksekveret: " << "*a er " << *a << " og *b er " << *b << "\n";
	double c=*a;
	*a=*b;
	*b=c;
	std::cout << "Efter kode er eksekveret: " << "*a er " << *a << " og *b er " << *b << "\n";
}

void swap_ref(double &a, double &b)
{
	std::cout << "Før kode er eksekveret: " << "&a er " << a << " og &b er " << b << "\n";
	double c=a;
	a=b;
	b=c;
	std::cout << "Efter kode er eksekveret: " << "&a er " << a << " og &b er " << b << "\n";
}
