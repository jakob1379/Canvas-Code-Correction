#include "2_6.h"
#include <cmath> //for using exp()
#include <iostream> //for using std::cout for printing

double newton_Raphson(double initialGuess, double epsilon){
	double x_prev = initialGuess;
    double x_next;
    double fx, f_diffx;
    int i;
    for (i = 0; i < 100; i++){
        //loop through Newton-Raphson solutions
        fx      = exp(x_prev)+pow(x_prev,3.0)-5.0;
        f_diffx = exp(x_prev)+3*pow(x_prev,2.0);
        x_next  = x_prev - (fx)/(f_diffx);
        
        if (abs(x_prev-x_next)<epsilon){
            std::cout << "Breaking at step i = " << i << " as tolerance of "<< epsilon << " has ben met.\n";
            break;
        }

        //Continue
        x_prev = x_next;
    //Output current x
    std::cout << "x = " << x_next << "\n";
    }
    
    return x_next;
}

/*newton_Raphson[0] = 0.0;
newton_Raphson[1] = 1e-8;
double fx;
double x;
x = newton_Raphson[0];
*/ 

