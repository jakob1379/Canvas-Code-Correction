#include "5_9.h"
#include "5_10.h"
void solve3by3(double **A, double *b, double *u)
{
    //Solve by calling general solver
    int n = 3;
    guassian_elimination(A,b,u,n);
    
}