#include "5_4.h"
#include <cmath>
double calc_std(double a[], int length)
{
    double std, mean;
    
    mean = calc_mean(a, length);
    
    int i;
    double sq_sum = 0;
    for (i=0;i<length;i++)
    {
        sq_sum += pow(a[i]-mean,2);
    }
    int divisor;
    if(i>1)
    {
        divisor = length-1; //Bessel's correction    
    }
    else
    {
        divisor = length; //length = 1
    }
    
    std = pow(sq_sum/divisor,0.5);

    return std;

}
double calc_mean(double a[], int length)
{
    double sum=0;
    int i;
    for (i=0;i<length;i++)
    {
        sum+=a[i];
    }
    return sum/((double)(length));
}

