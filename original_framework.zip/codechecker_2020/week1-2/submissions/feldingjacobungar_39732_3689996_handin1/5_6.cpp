#include "5_6.h"
#include <cassert>

//Two helper functions below, from textbook
//Allocate matrix memory
double** AllocateMatrixMemory(int numRows, int numCols)
{
	double** matrix;
	matrix = new double* [numRows];
	for (int i=0; i<numRows; i++)
	{
		matrix[i] = new double [numCols];
	}
	return matrix;
}

//Free matrix memory again
void FreeMatrixMemory(int numRows, double** matrix)
{
	for (int i=0; i<numRows; i++)
	{
		delete[] matrix[i];
	}
	delete[] matrix;
}

void Multiply(double **res, double **A, double **B, int ARows, int ACols, int BRows, int BCols)
{
    //5.5. function to multiply two matrices A and B given also their sizes ARows, ACols and BRows, BCol
    //Must use assertions to verify that matrices can be multiplied
    assert(ACols == BRows);
    ResetElements(res,ARows,BCols);
    //Multiplication
    for (int i=0;i<ARows;i++)
    {
        for (int j=0;j<BCols;j++)
        {
            for(int n=0;n<ACols;n++)
            {
                res[i][j]+=A[i][n]*B[n][j];
            }
            
        }
    }


}

void Multiply(double *res, double *A, double **B, int ACols, int BRows, int BCols)
{
    //Overloading function to multiply vector A with matrix B
    //A is a row vector.
    //Matrix B must have same number of rows as (row vector) has columns
    assert(ACols=BRows);
    //res must be row vector 1xBCols //assert(res...)
    ResetElements(res,BCols);

    for (int i=0; i<BCols;i++)
    {
        for (int j=0; j<ACols;j++)
        {
            res[i]+=A[j]*B[j][i];
        }
    }


}

void Multiply(double *res, double **A, double *B, int ARows, int ACols, int BRows)
{
    //Overloading function to multiply Matrix A with vector B
    //B is a column vector.
    //Matrix A must have same number of columns as (column vector) has rows
    assert(ACols==BRows);
    //res must be row vector 1xACols 
    ResetElements(res,ACols);

    for (int i=0; i<ARows;i++)
    {
        for (int j=0; j<ACols;j++)
        {
            res[i]+=A[i][j]*B[j];
        }
    }

}


void Multiply(double **res, double scalar, double **B, int BRows, int BCols)
{
    // Multiply scalar with matrix
    ResetElements(res,BRows,BCols);

    for (int i=0; i<BRows;i++)
    {
        for (int j=0; j<BCols;j++)
        {
            res[i][j]=scalar*B[i][j];
        }
    }

}

void Multiply(double **res, double **B, double scalar, int BRows, int BCols)
{   
    
    // Multiply scalar with matrix
    ResetElements(res,BRows,BCols);

    for (int i=0; i<BRows;i++)
    {
        for (int j=0; j<BCols;j++)
        {
            res[i][j]=scalar*B[i][j];
        }
    }

}

void ResetElements(double** res, int rows, int cols)
{
    //clear resulting matrix to make sure that += for matrix 
    //multiplication does not add to existing values in res
    for (int i=0;i<rows;i++)
    {
        for (int j=0;j<cols;j++)
        {
            res[i][j]=0;
        }
    }
}
void ResetElements(double* res, int n)
{
    //clear resulting matrix to make sure that += for matrix 
    //multiplication does not add to existing values in res
    for (int i=0;i<n;i++)
    {
        res[i]=0;
    }

}

void Identity(double** res, int rows, int cols)
{
    //clear resulting matrix to make sure that += for matrix 
    //multiplication does not add to existing values in res
    for (int i=0;i<rows;i++)
    {
        for (int j=0;j<cols;j++)
        {   
            if(i==j)
            {
                res[i][j]=1;
            }
            else
            {
                res[i][j]=0;
            }
        }
    }
}

