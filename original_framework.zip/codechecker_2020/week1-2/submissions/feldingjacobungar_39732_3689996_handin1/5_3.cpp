#include "5_3.h"

//void swap_pointer( double *a , double *b);
//void swap_ref( double &a , double &b) ;


void swap_pointer( double *  a , double *b){
    double temp_a;
    double temp_b;
    //swap values of variables a and b using references
    // a stored adress of a_num. *a is content at that adress, i.e. a_num
    temp_a = *b;
    temp_b = *a;
    *a = temp_a;
    *b = temp_b;
    return;
}

void swap_ref( double &a , double &b)
{
    //a and b are references to variables a_num and b_num with different names 
    double temp_a, temp_b;
    temp_a = b;
    temp_b = a;

    a = temp_a;
    b = temp_b;
}