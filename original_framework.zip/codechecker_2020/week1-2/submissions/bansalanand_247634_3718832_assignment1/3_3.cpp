#include <iostream>
#include <cassert>
#include <fstream>
#include "3_3.h"

void implicit_Euler(int n)
{

	assert(n>1);
	double h = 1/((double)(n));

	double x[n], y[n];

	for(int i=0; i<n; i++)
		x[i] = i*h;

	y[0] = 1;
	for(int i=1; i<n; i++)
		y[i] = y[i-1]/(1+h);

	std::ofstream write_output("xy.dat");
	assert(write_output.is_open());

	for(int i=0; i<n; i++)
	{
		write_output << x[i] << "," << y[i] << "\n";
		write_output.flush();
	}

	write_output.close();

}