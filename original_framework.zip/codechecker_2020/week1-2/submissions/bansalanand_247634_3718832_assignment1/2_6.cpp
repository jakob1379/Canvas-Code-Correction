#include <iostream>
#include <cmath>
#include "2_6.h"

double newton_Raphson(double initialGuess, double epsilon)
{
	
	double x, y, f, d, diff;

	x = initialGuess;

	do
	{
		f = exp(x) + pow(x, 3) - 5;
		d = exp(x) + 3*pow(x, 2);
		y = x - f/d;
		diff = fabs(y - x);
		x = y;
	}
	while (diff > epsilon);

	return y;
	
}