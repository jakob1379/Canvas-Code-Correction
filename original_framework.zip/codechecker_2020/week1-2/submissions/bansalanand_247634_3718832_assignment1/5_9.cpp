#include <iostream>
#include "5_9.h"

void solve3by3(double **A, double *b, double *u)
{

	int n = 3, max;
	double m, temp, tempB, tempRow[n];
	
	for(int k=1; k<n; k++)
	{
		max = k-1;
		for(int i=k-1; i<n; i++)
			if(A[i][k-1] > A[max][k-1])
				max = i;
		
		if(max!=k-1)
		{
			for(int j=0; j<n; j++)
			{
				tempRow[j]= A[k-1][j];
				A[k-1][j] = A[max][j];
				A[max][j] = tempRow[j];
			}
			tempB = b[k-1];
			b[k-1] = b[max];
			b[max] = tempB;
		}

		for(int i=k; i<n; i++)
		{
			m = A[i][k-1]/A[k-1][k-1];
			for(int j=k-1; j<n; j++)
				A[i][j] -= m*A[k-1][j];

			b[i] -= m*b[k-1];
		}
	}

	for(int k=n-1; k>-1; k--)
	{
		temp = 0;
		for(int i=k+1; i<n ;i++)
			temp += A[k][i]*u[i];
		u[k] = (b[k] - temp)/A[k][k];
	}

}