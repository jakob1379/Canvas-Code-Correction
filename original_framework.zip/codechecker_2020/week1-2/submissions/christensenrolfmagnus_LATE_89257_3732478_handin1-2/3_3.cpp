#include "3_3.h"
#include <iostream>
#include <cmath>
#include <cassert>
#include <fstream>

void implicit_Euler(int n)
{
    assert(n > 1);

    double h = 1/((double)n);
    // The stepsize is calculated by dividing one by number of steps (since 0 <= x <=1)

    const int steps = n;
    const int cols = 2;

    double x = 0;
    double y = 1;
    
    std::ofstream write_output("xy.dat");
    assert(write_output.is_open());
    // create output file xy.dat and make sure it is open

        for (int i=1; i < steps; i++)
    {
        x = h*i;
        y = y/(h+1);
        // derived way of calculating yn from: -yn = (yn - yn-1) / h  --> yn = yn-1 / (h + 1)
        write_output << "x" << i << " = " << x << "  " << "y" << i << " = " << y/(h+1) << "\n\n"; 
    }
    write_output.close();
} 
