//
//  5_4.cpp
//  Handin1
//
//  Created by Christiane Annodine Duus-Holm on 26/04/2020.
//  Copyright © 2020 Christiane Annodine Duus-Holm. All rights reserved.
//

#include <stdio.h>
#include "5_4.h"
#include <cassert>
#include <cmath>

//Implementation mean
double calc_mean(double a[], int length)
{
    if(length>0) //indicating there actually is a number/array
    {
        double mean=0; //Declaring the mean
        double sum=0; //Declaring the sum
        for (int i=0; i<length; i++)
        {
            sum+=a[i]; //Calculating the sum
        }
        mean=sum/length;
        return mean;
    }
    else{ //If length eqaul to 0, there is no number, so just returning 0 so something is returned
        return 0;
    }
}

//Implementation sd
double calc_std(double a[], int length){
    double mean=calc_mean(a, length);
    //calculating sum in sd
    double sumarray[length];
    
    if(length>1)
    {
        for (int i=0; i<length; i++)
        {
            sumarray[i]=pow((a[i]-mean),2);
        }
        double sdsum=0;
        for (int i=0; i<length; i++)
        {
            sdsum+=sumarray[i];
        }
        double sd=0;
        sd=sqrt(sdsum/(length-1));
        return sd;
    }
    else{ //if length=1, then there is no sd
        return 0;
    }
}
