#include <iostream>
#include <cmath>
#include "3_3.h"
#include <cassert>
using namespace std; 
#include <fstream>

void implicit_Euler(int n)
{
	assert(n >= 1);	
	double k=n;
	double h=(1/k);
	double y=1;
	ofstream MyFile("xy.dat");
	MyFile << 0 << "," << 1 << "\n";
	for (int i=1; i<n; i++)
	{
		if (h*i<=1)
		{y=y/(h+1);
		MyFile << h*i << "," << y << "\n";}
	}
}

