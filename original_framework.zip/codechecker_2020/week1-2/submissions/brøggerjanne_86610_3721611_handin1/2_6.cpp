#include <iostream>
#include <cmath>
#include "2_6.h"

double newton_Raphson(double initialGuess, double epsilon)
{
	double x=initialGuess;
	double f=(exp(x)+x*x*x-5)/(exp(x)+3*x*x);
	x=x-f;
	while (sqrt(pow(f,2))>epsilon)
	{
		f=(exp(x)+x*x*x-5)/(exp(x)+3*x*x);
		x=x-f;
	}
	return x;
}
