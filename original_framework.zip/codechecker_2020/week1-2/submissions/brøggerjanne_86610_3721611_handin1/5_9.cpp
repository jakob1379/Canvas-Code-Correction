#include <iostream>
#include <cmath>
#include "5_9.h"




void solve3by3(double **A, double *b, double *u)
{
	double detA;	
	detA=A[0][0]*(A[1][1]*A[2][2]-A[1][2]*A[2][1])-A[0][1]*(A[1][0]*A[2][2]-A[1][2]*A[2][0])+A[0][2]*(A[1][0]*A[2][1]-A[1][1]*A[2][0]);

	double Ainv[3][3];
	Ainv[0][0]=(A[1][1]*A[2][2]-A[1][2]*A[2][1])/detA;
	Ainv[0][1]=(A[0][2]*A[2][1]-A[0][1]*A[2][2])/detA;
	Ainv[0][2]=(A[0][1]*A[1][2]-A[0][2]*A[1][1])/detA;
	Ainv[1][0]=(A[1][2]*A[2][0]-A[1][0]*A[2][2])/detA;
	Ainv[1][1]=(A[0][0]*A[2][2]-A[0][2]*A[2][0])/detA;
	Ainv[1][2]=(A[0][2]*A[1][0]-A[0][0]*A[1][2])/detA;
	Ainv[2][0]=(A[1][0]*A[2][1]-A[1][1]*A[2][0])/detA;
	Ainv[2][1]=(A[0][1]*A[2][0]-A[0][0]*A[2][1])/detA;
	Ainv[2][2]=(A[0][0]*A[1][1]-A[0][1]*A[1][0])/detA;


	for (int i=0; i<3; i++)
	{
		for (int j=0; j<3; j++)
		{
			u[i] += Ainv[i][j]*b[j];
		}
	}
}	


