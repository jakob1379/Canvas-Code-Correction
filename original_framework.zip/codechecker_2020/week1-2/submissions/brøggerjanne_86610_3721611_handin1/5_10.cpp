#include <iostream>
#include <cmath>
#include "5_10.h"
#include <fstream>


void guassian_elimination(double **A, double *b, double *u, int n)
{
	double AN[n][n];
	for (int i=0; i<n; i++)
	{	
		for (int j=0; j<n; j++)
		{
			AN[i][j]=A[i][j];
		}
	}
	double bn[n];
	for (int k=0; k<n; k++)	
	{
		bn[k]=b[k];
	}
	
	double max[n];
		for (int d=0; d<n; d++)
		{
			max[d]=0.00001;
		}

	for (int h=0; h<n; h++)
	{
	
		for (int l=h; l<n; l++)
		{
			if (fabs(AN[l][h])>fabs(max[h])) 
			{
				max[h]=AN[l][h];
			
				double C[n];
				double M;
				M=bn[h];
				bn[h]=bn[l];
				bn[l]=M;
				for (int m=0; m<n; m++)
				{			
					C[m]=AN[h][m];

				}			
				for (int f=0; f<n; f++)
				{			
					AN[h][f]=AN[l][f];
				}			
				for (int p=0; p<n; p++)
				{			
					AN[l][p]=C[p];
				}
			}
		}
	
		double times[n];
		for (int r=(h+1); r<n; r++)
		{
			times[r]=AN[r][h]/max[h];
			bn[r]=bn[r]-bn[h]*times[r];
			for (int s=0; s<n; s++)
			{
				AN[r][s]=AN[r][s]-AN[h][s]*times[r];
			}
		}
		
	}

	u[n-1]=bn[n-1]/AN[n-1][n-1];
	for (int e=0; e<(n-1); e++)
	{	
		double minus=0.0;
		for (int y=0; y<(e+1); y++)
		{
			minus=minus+AN[(n-2)-e][(n-1)-y]*u[(n-1)-y];
		}
		u[(n-2)-e]=(bn[(n-2)-e]-minus)/AN[(n-2)-e][(n-2)-e];
	}
	
}	





	
