#include <iostream>
#include <cmath>
#include "5_4.h"


double calc_mean(double a[], int length)
{
	double sum=0;
	for (int i=0; i<length; i++)
	{
		sum=sum+a[i];
	}
	double mean=sum/length;
	return mean;
}

double calc_std(double a[], int length)
{
	double sumdiff=0;
	double M=calc_mean(a,length);
	for (int i=0; i<length; i++)
	{
		sumdiff=sumdiff+pow((a[i]-M),2);
	}
	double standarddiv=sqrt(sumdiff/(length-1));
	return standarddiv;
}
