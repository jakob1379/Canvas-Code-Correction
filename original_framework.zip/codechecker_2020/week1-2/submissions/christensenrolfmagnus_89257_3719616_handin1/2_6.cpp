#include "2_6.h"
#include <iostream>
#include <cmath>

double fx(double x)
// double -> double
// f(x)= e^x + x^3 − 5
//This is the non-linear funtion we are trying to solve.
{
    return exp(x) + pow(x,3) - 5;
}

double deriv_fx (double x)
// double -> double
// f(x)= e^x + 3 * x^2
//This is the derivative of our non-linear funtion.
{
    return exp(x) + 3*pow(x,2);
}


double newton_Raphson(double initialGuess, double epsilon)
    {
        // create pointers for the x_next and x_prev variables
        double* x_next; 
        x_next = new double;
        
        double* x_prev; 
        x_prev = new double;
        *x_prev = initialGuess;

        int i = 0;

        // I am using a boolian flag to check for convergence
        bool* convergence; 
        convergence = new bool;
        *convergence = false;

        while(*convergence == false && i<100) //max iterations is 100
            {
                
                *x_next = *x_prev - (fx(*x_prev)/deriv_fx(*x_prev));
                
                if (fx(*x_next) > fx(*x_prev) && i!=0)
                // This check is implemented to make sure the program is converging.
                // if f(x_next) is not smaller (closer to zero) than f(x_prev), it means something is wrong and the program stops.
                {
                    std::cout << "Error: Not converging towards f(x)=0";
                    break;
                }

                std::cout << "x";
                std::cout << i;
                std::cout << "= ";
                std::cout << *x_prev;
                std::cout << "\n\n";

                if (fabs(*x_next - *x_prev) < epsilon)
                // convergence is achieved when |xi - xi-1| is smaller than ε. 
                {
                    *convergence = true;
                    std::cout << "\nConvergence!\n\nx";
                    std::cout << i+1;
                    std::cout << "= ";
                    std::cout << *x_next;
                    std::cout << "\n\niterations: ";
                    std::cout << i;
                }
                *x_prev = *x_next;
                i++;
            }   
        return 0;
        //returns zero if program successfully makes it through the while-loop.
    }