#include "3_3.h"
#include <iostream>
#include <cmath>
#include <cassert>
#include <fstream>

void implicit_Euler(int n)
{
    std::cout << "Please type the number of grids " ;
    std::cin >> n;
    assert(n > 1);

    double h = 1/((double)n);
    // The stepsize is calculated by dividing one by number of steps (since 0 <= x <=1)

    const int steps = n;
    const int cols = 2;

    double** xy = new double* [steps];
    //create a dynamic array, so that its size matches exactly to the number of grids
    // xy = array[n][2]

    std::ofstream write_output("xy.dat");
    assert(write_output.is_open());
    // create output file xy.dat and make sure it is open


    for (int i=0; i<steps; i++)
    {
        xy[i] = new double[cols]; //for each row, allocate memory for two columns
        if (i==0)
        {
            // The first value of y is given: y(0) = 1
            xy[i][0] = 0;
            xy[i][1] = 1;
        }
    }
    for (int i=1; i < steps; i++)
    {
        xy[i][0] = h*i;
        xy[i][1] = xy[(i-1)][1] / (h + 1) ; // derived way of calculating yn from: -yn = (yn - yn-1) / h  --> yn = yn-1 / (h + 1)
        
        write_output << "x" << i << " = " << xy[i][0] << "  " << "y" << i << " = " << xy[i][1] << "\n\n"; 
        
        std::cout<< "\nx = ";
        std::cout<< xy[i][0];
        std::cout<< "\n";
        std::cout<< "y = ";
        std::cout<< xy[i][1];
        std::cout<< "\n\n";
    }
    write_output.close();

}