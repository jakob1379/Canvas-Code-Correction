#include "5_3.h"
#include <iostream>

void swap_pointer(double *a, double *b)
{   
    double copy_a = *a;

    double copy_b = *b;

    *a = copy_b;
    *b = copy_a; 
}


void swap_ref(double &a, double &b)
{
    double copy_a = a;

    double copy_b = b;

    a = copy_b;
    b = copy_a;
}