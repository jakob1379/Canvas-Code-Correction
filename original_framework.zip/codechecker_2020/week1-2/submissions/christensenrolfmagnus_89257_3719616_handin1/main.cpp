#include <iostream>
#include <sstream>
#include <ctime>
#include <cmath>
#include <random>

#include "./2_6.h"
#include "./3_3.h"
#include "./5_3.h"
#include "./5_4.h"
#include "./5_6.h"
#include "./5_9.h"
#include "./5_10.h"



int main(int argc, char* argv[])
{
    // 2_6
    std::cout<<"Exercise 2_6:\n";

    double Guess = 0, e = 1.0e-6;
    double newton = newton_Raphson(Guess, e);
    std::cout<< newton;
    std::cout<<"\n\n";

    // 3_3
    std::cout<<"Exercise 2_6:\n";
    int* num;
    num = new int;
    implicit_Euler(*num);

    delete[] num;
    std::cout<<"\n\n";
    
    // 5_3
    std::cout << "Exercise 5_3:\n" ;
    double* a_3;
    a_3 = new double;
    *a_3 = 4.00; 

    double* b_3;
    b_3 = new double;
    *b_3 = 8.00;
    
    std::cout << "Pointers: \n" ;
    std::cout << "Before:\n" ;
    std::cout << *a_3;
    std::cout << " " ;
    std::cout << *b_3;
    std::cout << "\n\n" ;

    swap_pointer(a_3, b_3);
    
    std::cout << "After:\n" ;
    std::cout << *a_3;
    std::cout << " " ;
    std::cout << *b_3;
    std::cout << "\n\n" ;

    delete[] a_3;
    delete[] b_3;

    double x = 4.00;
    double y = 8.00;

    std::cout << "References: \n" ;
    std::cout << "Before:\n" ;
    std::cout << x;
    std::cout << " " ;
    std::cout << y;
    std::cout << "\n\n" ;

    swap_ref(x, y);
    
    std::cout << "After:\n" ;
    std::cout << x;
    std::cout << " " ;
    std::cout << y;
    std::cout << "\n\n" ;

    // 5_4
    std::cout<< "Exercise 5_9:\n";
    double X[10] = {5.0, 10.0, 15.0, 20.0, 25.0, 30.0, 35.0, 40.0, 45.0, 50.0};
    std::cout<<"a = {5.0, 10.0, 15.0, 20.0, 25.0, 30.0, 35.0, 40.0, 45.0, 50.0}";
    std::cout<<"\n\n";

    int length = 10;
    calc_std(X, length);

    // 5_6
    int A_rows = 3;
    int A_cols = 3;

    int B_rows = 3;
    int B_cols = 3;

    double** A_matrix;

    A_matrix = new double* [A_rows];

    for(int i=0; i<A_rows; i++)
    {
        A_matrix[i] = new double[A_cols];
    }

    A_matrix[0][0] = 5;
    A_matrix[0][1] = 3;
    A_matrix[0][2] = 2;

    A_matrix[1][0] = 4;
    A_matrix[1][1] = 1;
    A_matrix[1][2] = 6;

    A_matrix[2][0] = 3;
    A_matrix[2][1] = 4;
    A_matrix[2][2] = 2;

    
    double** B_matrix;

    B_matrix = new double* [B_rows];

    for(int i=0; i<B_rows; i++)
    {
        B_matrix[i] = new double[B_cols];
    }

    B_matrix[0][0] = 2;
    B_matrix[0][1] = 1;
    A_matrix[0][2] = 4;

    B_matrix[1][0] = 6;
    B_matrix[1][1] = 3;
    B_matrix[1][2] = 1;

    B_matrix[2][0] = 2;
    B_matrix[2][1] = 4;
    B_matrix[2][2] = 3;

    
    double* vector;
    vector = new double [B_rows];

    vector[0] = 5; 
    vector[1] = 4;
    vector[2] = 3;
    vector[3] = 5;

    double** res_matrix;

    res_matrix = new double* [A_rows];

    for(int i=0; i<A_rows; i++)
    {
        res_matrix[i] = new double[A_rows];
    }

    
    double* res_vector;
    res_vector = new double [B_rows];

    double scalar = 4;

    Multiply(res_matrix, A_matrix, B_matrix, A_rows, A_cols, B_rows, B_cols);
    
    std::cout<< "Results of matrix-matrix multiplication: \n";
    for(int x=0; x<A_rows; x++)
    {
        for(int y=0; y<A_cols; y++)
        {
            std::cout<< res_matrix[x][y];
            std::cout<< " ";
        }
        std::cout<< "\n";
    }
    std::cout<< "\n\n";

    Multiply(res_vector, vector, B_matrix, A_cols, B_rows, B_cols);
    std::cout<< "Results of vector-matrix multiplication: \n";
    for(int x=0; x<A_rows; x++)
    {
            std::cout<< res_vector[x];
            std::cout<< " ";
    }
    std::cout<< "\n\n";


    Multiply(res_vector, A_matrix, vector, A_rows, A_cols, B_rows);
    std::cout<< "Results of matrix-vector multiplication: \n";
    for(int x=0; x<A_rows; x++)
    {
            std::cout<< res_vector[x];
            std::cout<< " ";
    }
    std::cout<< "\n\n";


    Multiply(res_matrix, scalar, B_matrix, B_rows, B_cols);
    std::cout<< "Results of scalar-matrix multiplication: \n";
    for(int x=0; x<A_rows; x++)
    {
        for(int y=0; y<A_cols; y++)
        {
            std::cout<< res_matrix[x][y];
            std::cout<< " ";
        }
        std::cout<< "\n";
    }
    std::cout<< "\n\n";

    Multiply(res_matrix, B_matrix, scalar, B_rows, B_cols);
    std::cout<< "Results of matrix-scalar multiplication: \n";
    for(int x=0; x<A_rows; x++)
    {
        for(int y=0; y<A_cols; y++)
        {
            std::cout<< res_matrix[x][y];
            std::cout<< " ";
        }
        std::cout<< "\n";
    }
    std::cout<< "\n\n";

    for(int i=0; i<A_rows; i++)
    {
        delete[] A_matrix[B_cols];
    }

    delete[] A_matrix;

    
    for(int i=0; i<B_rows; i++)
    {
        delete[] B_matrix[B_cols];
    }

    delete[] B_matrix;

    
    for(int i=0; i<B_rows; i++)
    {
        delete[] res_matrix[B_cols];
    }

    delete[] res_matrix;

    delete[] res_vector;
    delete[] vector;

    // 5_9
    std::cout<< "Exercise 5_9:\n";
    const int N = 3;
    double** a;

    a = new double* [N];

    for(int i=0; i<N; i++)
    {
        a[i] = new double[N];
    }

    a[0][0] = 2;
    a[0][1] = -1;
    a[0][2] = 1;

    a[1][0] = 4;
    a[1][1] = 1;
    a[1][2] = -1;

    a[2][0] = 1;
    a[2][1] = 1;
    a[2][2] = 1;

    
    double* B;
    B = new double[N];

    B[0]= 5; 
    B[1]= 5;
    B[2]= 5;

    double* U;
    U = new double[N];
    
    solve3by3(a, B, U);

    for(int i=0; i<N; i++)
    // print result of solve3by3
    {
        std::cout<< U[i];
        std::cout<< " ";
    }
    std::cout<< "\n\n";

    for(int i=0; i<N; i++)
    {
        delete[] a[i];
    }

    delete[] a;
    delete[] B;
    delete[] U;


    // 5_10
    std::cout<< "Exercise 5_10:\n";
    
    const int n = 4;
    double** A;

    A = new double* [n];

    for(int i=0; i<n; i++)
    {
        A[i] = new double[n];
    }

    A[0][0] = 0;
    A[0][1] = 2;
    A[0][2] = -1;
    A[0][3] = 1;

    A[1][0] = 4;
    A[1][1] = 0;
    A[1][2] = 1;
    A[1][3] = -1;

    A[2][0] = 1;
    A[2][1] = 1;
    A[2][2] = 1;
    A[2][3] = 1;
    
    A[3][0] = 4;
    A[3][1] = -1;
    A[3][2] = 2;
    A[3][3] = 1;

    
    double* b;
    b = new double[n];

    b[0]= 5; 
    b[1]= 2;
    b[2]= 5;
    b[2]= 2;

    double* u;
    u = new double[n];
    
    guassian_elimination(A, b, u, n);

    for(int i=0; i<n; i++)
    // print result of guassian_elimination
    {
        std::cout<< u[i];
        std::cout<< " ";
    }

    for(int i=0; i<n; i++)
    {
        delete[] A[i];
    }
    delete[] A;
    delete[] b;
    delete[] u;

    return 0;
}