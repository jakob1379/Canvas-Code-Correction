#include "5_6.h"
#include <iostream>
#include <cmath>
#include <cassert>

void Multiply(double **res, double **A, double **B, int ARows, int ACols, int BRows, int BCols)
{
    assert(ACols == BRows);

    for(int i=0; i<ARows; i++)
    {
        for(int n=0; n<BCols; n++)
        {
        double sum = 0;
            for(int j=0; j<ACols; j++)
            {
                sum += (A[i][j] * B[j][n]);
            }
        res[i][n]= sum;
        }
    }

}

void Multiply(double *res, double *A, double **B, int ACols, int BRows, int BCols)
{
        assert(ACols == BRows);

        for(int i=0; i<BCols; i++)
        {
        double sum = 0;
            for(int j=0; j<ACols; j++)
            {
                sum += (A[j] * B[j][i]);
            }
        res[i]= sum;
        }
}

void Multiply(double *res, double **A, double *B, int ARows, int ACols, int BRows)
{
    assert(ACols == BRows);

    for(int i=0; i< ARows; i++)
    {
        double sum = 0;
        for (int n=0; n<BRows; n++)
        {
            sum += (A[i][n] * B[n]);
        }
        res[i] = sum;
    }
}

void Multiply(double **res, double scalar, double **B, int BRows, int BCols) 
{
    for (int i=0; i<BRows; i++)
    {
        for (int n=0; n<BCols; n++)
        {
            res[i][n] = B[i][n] * scalar;
        }
    }
}

void Multiply(double **res, double **B, double scalar, int BRows, int BCols)
{
    for (int i=0; i<BRows; i++)
    {
        for (int n=0; n<BCols; n++)
        {
            res[i][n] = B[i][n] * scalar;
        }
    }
}