#include "5_9.h"
#include <iostream>
#include <cmath>

void solve3by3(double **A, double *b, double *u)
{
    int n = 3;
    for(int k=0; k<(n-1); k++)
    // Gaussian elimination
    {
        for(int i =(k+1); i<n; i++)
        {    
            // find suitable multiple
            double m = A[i][k]/A[k][k];

            for(int j=0; j <= n; j++)
            {
                A[i][j] -= m * A[k][j];
            }
            b[i] = b[i] - m*b[k];
        }
    }

    //assign value u[n-1]
    u[n-1] = b[n-1] / A[n-1][n-1];

    for(int k=(n-2); k >= 0; k--)
    // compute back-substitution
    {
        double sum = 0;
        for(int i=(k+1); i<n; i++)
        {
            sum += A[k][i] * u[i];
        }
        u[k] = (b[k] - sum) / A[k][k];
    }

}