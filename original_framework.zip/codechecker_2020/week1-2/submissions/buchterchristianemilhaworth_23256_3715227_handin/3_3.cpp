#include "3_3.h"
#include <cassert> //assert
#include <fstream> //write to file

void implicit_Euler(int n){

	assert(n>1);

	double y = 1.0;
	double x = 0.0;
	double stepSize = 1.0/n;
	
	std::ofstream write_output("xy.dat");
	assert(write_output.is_open());
	for(int i = 0; i <= n; i++){
		write_output << x << "," << y << std::endl;
		x += stepSize;
		y = y/(x+1);
	}
	write_output.close();
}
