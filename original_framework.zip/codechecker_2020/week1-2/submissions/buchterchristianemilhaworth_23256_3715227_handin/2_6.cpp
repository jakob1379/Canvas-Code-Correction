#include "2_6.h"
#include <cmath>        // fabs, exp, pow

double newton_Raphson(double initialGuess, double epsilon){
	double x_prev = initialGuess;
	double x_next = x_prev - f(x_prev)/fDerived(x_prev);

	while(fabs(x_prev-x_next) < epsilon){
		x_prev = x_next;
		x_next = x_prev - f(x_prev)/fDerived(x_prev);
	}
	return x_next;

}

double f(double x){
	return exp(x) + pow(x,3) - 5;
}

double fDerived(double x){
	return exp(x)-3*pow(x,2);
}
