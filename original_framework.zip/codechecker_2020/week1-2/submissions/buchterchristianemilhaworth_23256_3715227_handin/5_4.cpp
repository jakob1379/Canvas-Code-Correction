#include "5_4.h"
#include <cmath>
double calc_std(double a[], int length){

	if(length < 2){
		return 0.0;
	}

	double variance = 0;
	double mean = calc_mean(a, length);

	for (int i = 0; i < length; i++) {
    		variance += pow(a[i]-mean,2)/(length-1);
	}
	return sqrt(variance);
}
double calc_mean(double a[], int length){
	double sum = 0;
	for (int i = 0; i < length; i++) {
    		sum += a[i];
	}
	return sum/length;
}
