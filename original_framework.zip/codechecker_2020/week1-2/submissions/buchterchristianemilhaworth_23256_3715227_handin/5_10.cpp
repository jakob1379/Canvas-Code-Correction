#include "5_10.h"
#include <cmath> // fabs

void guassian_elimination(double **A, double *b, double *u, int n){
	double temp;
	for (int i = 0; i < n; i++){
		// make A[i][i] (absolute) max of elements in {A[i][k] | k <= i}
		// This also ensures no zeroes in diagonal since A nonsingular
		for (int j = i+1; j < n; j++){
			if (fabs(A[i][i]) < fabs(A[j][i])){
				// swap RHS
				temp = b[i];
				b[i] = b[j];
				b[j] = temp;
				for (int k=0; k < n; k++){ 
					// swap rows
					temp = A[i][k];
                    			A[i][k] = A[j][k];
                    			A[j][k] = temp;
                		}
	    		}
		}
	}
	for (int i = 0; i < n ; i++){
		// make diagonal 1
		b[i] = b[i]/A[i][i];
		for(int j = 0; j < n; j++){
			A[i][j] = A[i][j]/A[i][i];
		}
		//make lower triangle 0
		for(int j = i+1; j < n; j++){
			b[j] -= b[i];
			for(int k = 0; k < n; k++){
				A[j][k] -= A[i][k];
			}
		}
	}
	for (int i = 0; i < n; i++){
		// zero upper triangle
		for (int j = i+1; j < n; j++){
			if (A[i][j] != 0){
				b[i] -= A[i][j] * b[j]; //A[j][j] is 1
				for (int k = 0; k < n; k++){
					A[i][k] -= A[i][j]*A[j][k];
				}
			}
		}
	}
	//Write result to u
	*u = *b;
}

