#include "5_6.h"
#include <cassert>

void Multiply(double **res, double **A, double **B, int ARows, 
	      int ACols, int BRows, int BCols){
	assert(ACols == BRows);
	for(int row = 0; row < ARows; row++){
		for(int col=0; col < BCols ; col++){
			res[row][col] = 0; //initialize entrance to 0
			for(int i = 0; i < BRows; i++){
				res[row][col] += A[row][i]*B[i][col];
			}
		}
	}
}

void Multiply(double *res, double *A, double **B, int ACols, 
	      int BRows, int BCols){
	assert(ACols == BRows);
	for(int col=0; col < BCols ; col++){
		res[col] = 0; //initialize entrance to 0
		for(int i = 0; i < BRows; i++){
			res[col] += A[i]*B[i][col];
		}
	}
}

void Multiply(double *res, double **A, double *B, int ARows, 
	      int ACols, int BRows){
	assert(ACols == BRows);
	for(int row = 0; row < ARows; row++){
		res[row] = 0; //initialize entrance to 0
		for(int i = 0; i < BRows; i++){
			res[row] += A[row][i]*B[i];
		}
	}
}

void Multiply(double **res, double scalar, double **B, int BRows, int BCols){
	for(int row = 0; row < BRows; row++){
		for(int col=0; col < BCols ; col++){
			res[row][col] = scalar * B[row][col];
		}
	}
}

// Scalar multiplicaton is commutative so this is just an overload of the 
// previous function in case the user decides on this input order.
void Multiply(double **res, double **B, double scalar, int BRows, int BCols){
	for(int row = 0; row < BRows; row++){
		for(int col=0; col < BCols ; col++){
			res[row][col] = scalar * B[row][col];
		}
	}
}
